using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Server
{
    public sealed class AlertManagementView : UserControl
    {
        private const int PageSize = 80;

        private readonly MySqlHistoryRepository repository = new MySqlHistoryRepository();
        private readonly List<AlertHistoryEntry> alerts = new List<AlertHistoryEntry>();

        private TextBox txtSearch = null!;
        private DataGridView gridAlerts = null!;
        private Label lblTotal = null!;
        private Label lblCritical = null!;
        private Label lblWarning = null!;
        private Label lblAck = null!;
        private Label lblCount = null!;
        private Label lblDetailTitle = null!;
        private Label lblDetailBed = null!;
        private Label lblDetailStatus = null!;
        private Label lblDetailTime = null!;
        private Label lblDetailMessage = null!;
        private Label lblSpo2 = null!;
        private Label lblHeart = null!;
        private Label lblTemp = null!;
        private Label lblDrip = null!;
        private Label lblTimeline = null!;
        private Button btnAckDetail = null!;
        private Button btnPrev = null!;
        private Button btnNext = null!;

        private string selectedFilter = "Tất cả";
        private AlertHistoryEntry? selectedAlert;
        private int currentPage;

        public AlertManagementView()
        {
            Dock = DockStyle.Fill;
            BackColor = Color.FromArgb(244, 248, 253);

            TableLayoutPanel root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 4,
                Padding = new Padding(18, 14, 18, 16)
            };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 92));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 54));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            Controls.Add(root);

            root.Controls.Add(CreateHeader(), 0, 0);
            root.Controls.Add(CreateFilters(), 0, 1);
            root.Controls.Add(CreateSortBar(), 0, 2);
            root.Controls.Add(CreateBody(), 0, 3);

            HandleCreated += async (s, e) => await LoadAlertsAsync();
        }

        public async Task RefreshFromDatabaseAsync()
        {
            await LoadAlertsAsync();
        }

        private Control CreateHeader()
        {
            TableLayoutPanel header = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 43));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 57));

            TableLayoutPanel titleBox = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
            titleBox.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 74));
            titleBox.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            Label icon = MakeLabel("⌁", 26, FontStyle.Bold, Color.FromArgb(55, 130, 245));
            icon.TextAlign = ContentAlignment.MiddleCenter;
            icon.BackColor = Color.FromArgb(232, 242, 255);
            icon.Margin = new Padding(0, 10, 14, 14);
            titleBox.Controls.Add(icon, 0, 0);

            TableLayoutPanel textBox = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2, ColumnCount = 1 };
            textBox.RowStyles.Add(new RowStyle(SizeType.Percent, 60));
            textBox.RowStyles.Add(new RowStyle(SizeType.Percent, 40));
            Label title = MakeLabel("GIAO DIỆN CẢNH BÁO", 20, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            Label subtitle = MakeLabel("Theo dõi và xử lý cảnh báo giường bệnh theo thời gian thực", 9, FontStyle.Regular, Color.FromArgb(95, 110, 130));
            title.TextAlign = ContentAlignment.BottomLeft;
            subtitle.TextAlign = ContentAlignment.TopLeft;
            textBox.Controls.Add(title, 0, 0);
            textBox.Controls.Add(subtitle, 0, 1);
            titleBox.Controls.Add(textBox, 1, 0);
            header.Controls.Add(titleBox, 0, 0);

            TableLayoutPanel stats = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 1 };
            for (int i = 0; i < 4; i++)
            {
                stats.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
            }

            lblTotal = AddHeaderStat(stats, 0, "●", "Tổng cảnh báo", Color.FromArgb(235, 54, 70));
            lblCritical = AddHeaderStat(stats, 1, "⚕", "Nguy cấp", Color.FromArgb(235, 54, 70));
            lblWarning = AddHeaderStat(stats, 2, "⚠", "Cảnh báo", Color.FromArgb(245, 132, 15));
            lblAck = AddHeaderStat(stats, 3, "✓", "Đã xác nhận", Color.FromArgb(0, 150, 84));
            header.Controls.Add(stats, 1, 0);
            return header;
        }

        private Control CreateFilters()
        {
            FlowLayoutPanel filters = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                WrapContents = false,
                FlowDirection = FlowDirection.LeftToRight,
                Padding = new Padding(0, 8, 0, 8)
            };

            txtSearch = new TextBox
            {
                Width = 430,
                Height = 32,
                PlaceholderText = "Tìm theo giường, phòng, loại cảnh báo...",
                Font = new Font("Segoe UI", 9),
                Margin = new Padding(0, 0, 10, 0)
            };
            txtSearch.TextChanged += (s, e) =>
            {
                currentPage = 0;
                RenderAlerts();
            };
            filters.Controls.Add(txtSearch);

            AddFilterButton(filters, "Tất cả", true);
            AddFilterButton(filters, "Nguy cấp", false);
            AddFilterButton(filters, "Cảnh báo", false);
            AddFilterButton(filters, "Chưa xác nhận", false);
            AddFilterButton(filters, "Đã xác nhận", false);
            return filters;
        }

        private Control CreateSortBar()
        {
            TableLayoutPanel bar = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, BackColor = Color.White };
            bar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            bar.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 250));

            Label sort = MakeLabel("Sắp xếp:  Mới nhất  •  Ưu tiên cao  •  Chưa xác nhận trước", 9, FontStyle.Regular, Color.FromArgb(18, 43, 73));
            sort.TextAlign = ContentAlignment.MiddleLeft;
            sort.Padding = new Padding(14, 0, 0, 0);
            bar.Controls.Add(sort, 0, 0);

            FlowLayoutPanel right = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft, WrapContents = false, BackColor = Color.White };
            Button refresh = MakeButton("⟳", Color.White, Color.FromArgb(0, 99, 255));
            refresh.Width = 42;
            refresh.Click += async (s, e) => await LoadAlertsAsync();
            btnNext = MakeButton("›", Color.White, Color.FromArgb(0, 99, 255));
            btnNext.Width = 36;
            btnNext.Click += (s, e) =>
            {
                currentPage++;
                RenderAlerts();
            };
            btnPrev = MakeButton("‹", Color.White, Color.FromArgb(0, 99, 255));
            btnPrev.Width = 36;
            btnPrev.Click += (s, e) =>
            {
                if (currentPage > 0)
                {
                    currentPage--;
                    RenderAlerts();
                }
            };
            lblCount = MakeLabel("0 cảnh báo", 8, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            lblCount.Width = 116;
            lblCount.TextAlign = ContentAlignment.MiddleRight;
            right.Controls.Add(refresh);
            right.Controls.Add(btnNext);
            right.Controls.Add(btnPrev);
            right.Controls.Add(lblCount);
            bar.Controls.Add(right, 1, 0);
            return bar;
        }

        private Control CreateBody()
        {
            TableLayoutPanel body = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
            body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70));
            body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));

            gridAlerts = new DataGridView
            {
                Dock = DockStyle.Fill,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                AutoGenerateColumns = false,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal,
                ColumnHeadersHeight = 38,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
                MultiSelect = false,
                ReadOnly = true,
                RowHeadersVisible = false,
                RowTemplate = { Height = 58 },
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                Margin = new Padding(0, 8, 10, 0)
            };
            gridAlerts.EnableHeadersVisualStyles = false;
            gridAlerts.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(246, 250, 255);
            gridAlerts.ColumnHeadersDefaultCellStyle.ForeColor = Color.FromArgb(18, 43, 73);
            gridAlerts.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 8, FontStyle.Bold);
            gridAlerts.DefaultCellStyle.Font = new Font("Segoe UI", 9, FontStyle.Regular);
            gridAlerts.DefaultCellStyle.ForeColor = Color.FromArgb(18, 43, 73);
            gridAlerts.DefaultCellStyle.SelectionBackColor = Color.FromArgb(231, 241, 255);
            gridAlerts.DefaultCellStyle.SelectionForeColor = Color.FromArgb(18, 43, 73);
            gridAlerts.Columns.Add(MakeTextColumn("Level", "Mức độ", 95));
            gridAlerts.Columns.Add(MakeTextColumn("Bed", "Giường", 116));
            gridAlerts.Columns.Add(MakeTextColumn("Message", "Nội dung", 320, true));
            gridAlerts.Columns.Add(MakeTextColumn("Metrics", "Chỉ số", 250));
            gridAlerts.Columns.Add(MakeTextColumn("Time", "Thời gian", 122));
            gridAlerts.Columns.Add(MakeTextColumn("Ack", "Trạng thái", 100));
            gridAlerts.Columns.Add(new DataGridViewButtonColumn
            {
                Name = "View",
                HeaderText = "",
                Text = "Xem",
                UseColumnTextForButtonValue = true,
                Width = 70
            });
            gridAlerts.Columns.Add(new DataGridViewButtonColumn
            {
                Name = "Acknowledge",
                HeaderText = "",
                Text = "Xác nhận",
                UseColumnTextForButtonValue = true,
                Width = 88
            });
            gridAlerts.CellFormatting += FormatGridCell;
            gridAlerts.CellClick += GridAlerts_CellClick;
            gridAlerts.CellContentClick += async (s, e) => await HandleGridButtonAsync(e);
            body.Controls.Add(gridAlerts, 0, 0);
            body.Controls.Add(CreateDetailPanel(), 1, 0);
            return body;
        }

        private Control CreateDetailPanel()
        {
            Panel panel = new Panel { Dock = DockStyle.Fill, BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle, Padding = new Padding(16), Margin = new Padding(0, 8, 0, 0) };
            TableLayoutPanel root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 7 };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 44));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 72));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 88));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 112));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 102));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 50));
            panel.Controls.Add(root);

            lblDetailTitle = MakeLabel("Chi tiết cảnh báo", 11, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            lblDetailTitle.TextAlign = ContentAlignment.MiddleLeft;
            root.Controls.Add(lblDetailTitle, 0, 0);

            TableLayoutPanel status = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
            status.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 55));
            status.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45));
            lblDetailStatus = MakeBadge("--", Color.FromArgb(95, 110, 130));
            lblDetailTime = MakeLabel("--", 8, FontStyle.Bold, Color.FromArgb(95, 110, 130));
            lblDetailTime.TextAlign = ContentAlignment.MiddleRight;
            status.Controls.Add(lblDetailStatus, 0, 0);
            status.Controls.Add(lblDetailTime, 1, 0);
            root.Controls.Add(status, 0, 1);

            lblDetailBed = MakeLabel("--", 12, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            lblDetailBed.BackColor = Color.FromArgb(248, 251, 255);
            lblDetailBed.TextAlign = ContentAlignment.MiddleLeft;
            lblDetailBed.Padding = new Padding(14, 0, 0, 0);
            root.Controls.Add(lblDetailBed, 0, 2);

            lblDetailMessage = MakeLabel("--", 9, FontStyle.Regular, Color.FromArgb(18, 43, 73));
            lblDetailMessage.TextAlign = ContentAlignment.TopLeft;
            lblDetailMessage.Padding = new Padding(0, 8, 0, 0);
            root.Controls.Add(lblDetailMessage, 0, 3);

            TableLayoutPanel metrics = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 1 };
            for (int i = 0; i < 4; i++)
            {
                metrics.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
            }

            lblSpo2 = AddMetric(metrics, 0, "SpO₂");
            lblHeart = AddMetric(metrics, 1, "Nhịp tim");
            lblTemp = AddMetric(metrics, 2, "Nhiệt độ");
            lblDrip = AddMetric(metrics, 3, "Nhỏ giọt");
            root.Controls.Add(metrics, 0, 4);

            lblTimeline = MakeLabel("Chọn một cảnh báo để xem chi tiết.", 8, FontStyle.Regular, Color.FromArgb(95, 110, 130));
            lblTimeline.TextAlign = ContentAlignment.TopLeft;
            lblTimeline.Padding = new Padding(0, 8, 0, 0);
            root.Controls.Add(lblTimeline, 0, 5);

            FlowLayoutPanel actions = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft, WrapContents = false };
            btnAckDetail = MakeButton("✓  Xác nhận cảnh báo", Color.FromArgb(0, 99, 255), Color.White);
            btnAckDetail.Width = 166;
            btnAckDetail.Click += async (s, e) => await AcknowledgeSelectedAsync();
            actions.Controls.Add(btnAckDetail);
            root.Controls.Add(actions, 0, 6);
            return panel;
        }

        private async Task LoadAlertsAsync()
        {
            try
            {
                Cursor = Cursors.WaitCursor;
                alerts.Clear();
                alerts.AddRange(await repository.LoadAlertsAsync());
                currentPage = 0;
                RenderAlerts();
            }
            catch (Exception ex)
            {
                alerts.Clear();
                gridAlerts.DataSource = null;
                lblCount.Text = "Lỗi MySQL";
                ShowAlertDetail(null, "Không đọc được cảnh báo MySQL: " + ex.Message);
                UpdateStats();
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        private void RenderAlerts()
        {
            string keyword = txtSearch.Text.Trim();
            List<AlertHistoryEntry> visible = alerts
                .Where(alert => FilterAlert(alert, keyword))
                .OrderBy(alert => alert.Acknowledged)
                .ThenByDescending(alert => alert.Level == "Nguy cấp")
                .ThenByDescending(alert => alert.CreatedAt)
                .ToList();

            int totalPages = Math.Max(1, (int)Math.Ceiling(visible.Count / (double)PageSize));
            if (currentPage >= totalPages)
            {
                currentPage = totalPages - 1;
            }

            List<AlertHistoryEntry> page = visible
                .Skip(currentPage * PageSize)
                .Take(PageSize)
                .ToList();

            gridAlerts.Rows.Clear();
            foreach (AlertHistoryEntry alert in page)
            {
                int rowIndex = gridAlerts.Rows.Add(
                    alert.Level.ToUpperInvariant(),
                    alert.BedId,
                    alert.Message,
                    BuildMetricLine(alert),
                    alert.CreatedAt.ToString("HH:mm dd/MM/yyyy"),
                    alert.Acknowledged ? "Đã xác nhận" : "Chưa xác nhận",
                    "Xem",
                    alert.Acknowledged ? "Đã xác nhận" : "Xác nhận");
                gridAlerts.Rows[rowIndex].Tag = alert;
            }

            lblCount.Text = visible.Count == 0
                ? "0 cảnh báo"
                : $"{currentPage + 1}/{totalPages} • {visible.Count} cảnh báo";
            btnPrev.Enabled = currentPage > 0;
            btnNext.Enabled = currentPage < totalPages - 1;
            UpdateStats();
            ShowAlertDetail(page.FirstOrDefault());
        }

        private bool FilterAlert(AlertHistoryEntry alert, string keyword)
        {
            bool matchKeyword = string.IsNullOrWhiteSpace(keyword)
                || alert.BedId.Contains(keyword, StringComparison.OrdinalIgnoreCase)
                || alert.DeviceId.Contains(keyword, StringComparison.OrdinalIgnoreCase)
                || alert.Message.Contains(keyword, StringComparison.OrdinalIgnoreCase)
                || alert.Type.Contains(keyword, StringComparison.OrdinalIgnoreCase);

            if (!matchKeyword)
            {
                return false;
            }

            return selectedFilter switch
            {
                "Nguy cấp" => alert.Level == "Nguy cấp",
                "Cảnh báo" => alert.Level == "Cảnh báo",
                "Chưa xác nhận" => !alert.Acknowledged,
                "Đã xác nhận" => alert.Acknowledged,
                _ => true
            };
        }

        private void GridAlerts_CellClick(object? sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || gridAlerts.Rows[e.RowIndex].Tag is not AlertHistoryEntry alert)
            {
                return;
            }

            ShowAlertDetail(alert);
        }

        private async Task HandleGridButtonAsync(DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || gridAlerts.Rows[e.RowIndex].Tag is not AlertHistoryEntry alert)
            {
                return;
            }

            string columnName = gridAlerts.Columns[e.ColumnIndex].Name;
            if (columnName == "View")
            {
                ShowAlertDetail(alert);
            }
            else if (columnName == "Acknowledge" && !alert.Acknowledged)
            {
                await AcknowledgeAsync(alert);
            }
        }

        private void FormatGridCell(object? sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex < 0 || gridAlerts.Rows[e.RowIndex].Tag is not AlertHistoryEntry alert)
            {
                return;
            }

            Color levelColor = GetLevelColor(alert.Level);
            gridAlerts.Rows[e.RowIndex].DefaultCellStyle.BackColor = alert.Acknowledged
                ? Color.FromArgb(250, 252, 255)
                : Color.White;

            if (gridAlerts.Columns[e.ColumnIndex].Name is "Level" or "Message")
            {
                e.CellStyle.ForeColor = levelColor;
                e.CellStyle.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            }

            if (gridAlerts.Columns[e.ColumnIndex].Name == "Ack")
            {
                e.CellStyle.ForeColor = alert.Acknowledged ? Color.FromArgb(0, 150, 84) : Color.FromArgb(235, 54, 70);
                e.CellStyle.Font = new Font("Segoe UI", 8, FontStyle.Bold);
            }
        }

        private void ShowAlertDetail(AlertHistoryEntry? alert, string? emptyText = null)
        {
            selectedAlert = alert;
            if (alert == null)
            {
                lblDetailStatus.Text = "--";
                lblDetailStatus.ForeColor = Color.FromArgb(95, 110, 130);
                lblDetailBed.Text = "--";
                lblDetailTime.Text = "--";
                lblDetailMessage.Text = emptyText ?? "Chưa có cảnh báo phù hợp.";
                lblSpo2.Text = "--";
                lblHeart.Text = "--";
                lblTemp.Text = "--";
                lblDrip.Text = "--";
                lblTimeline.Text = "Chưa có dữ liệu.";
                btnAckDetail.Enabled = false;
                return;
            }

            Color levelColor = GetLevelColor(alert.Level);
            lblDetailStatus.Text = alert.Level.ToUpperInvariant();
            lblDetailStatus.ForeColor = levelColor;
            lblDetailBed.Text = "▭  " + alert.BedId + Environment.NewLine + "Thiết bị: " + alert.DeviceId;
            lblDetailTime.Text = alert.CreatedAt.ToString("HH:mm") + Environment.NewLine + alert.CreatedAt.ToString("dd/MM/yyyy");
            lblDetailMessage.Text = "Loại cảnh báo: " + alert.Type + Environment.NewLine
                + "Nội dung: " + alert.Message + Environment.NewLine
                + "Trạng thái: " + (alert.Acknowledged ? "Đã xác nhận" : "Chưa xác nhận");
            lblSpo2.Text = FormatPercent(alert.Spo2);
            lblHeart.Text = FormatNumber(alert.HeartRate) + " bpm";
            lblTemp.Text = FormatTemperature(alert.Temperature);
            lblDrip.Text = FormatDrip(alert.DripRate);
            lblTimeline.Text = "Lịch sử sự kiện" + Environment.NewLine
                + "● " + alert.CreatedAt.AddSeconds(-20).ToString("HH:mm") + "  Nhận dữ liệu từ thiết bị" + Environment.NewLine
                + "○ " + alert.CreatedAt.AddSeconds(-10).ToString("HH:mm") + "  Phát hiện vượt ngưỡng" + Environment.NewLine
                + "● " + alert.CreatedAt.ToString("HH:mm") + "  Tạo cảnh báo mức " + alert.Level;
            btnAckDetail.Enabled = !alert.Acknowledged;
        }

        private async Task AcknowledgeSelectedAsync()
        {
            if (selectedAlert != null)
            {
                await AcknowledgeAsync(selectedAlert);
            }
        }

        private async Task AcknowledgeAsync(AlertHistoryEntry alert)
        {
            try
            {
                await repository.AcknowledgeAlertAsync(alert.Id);
                await LoadAlertsAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không xác nhận được cảnh báo trong MySQL:\n" + ex.Message, "Lỗi MySQL", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateStats()
        {
            lblTotal.Text = alerts.Count.ToString();
            lblCritical.Text = alerts.Count(item => item.Level == "Nguy cấp" && !item.Acknowledged).ToString();
            lblWarning.Text = alerts.Count(item => item.Level == "Cảnh báo" && !item.Acknowledged).ToString();
            lblAck.Text = alerts.Count(item => item.Acknowledged).ToString();
        }

        private void AddFilterButton(FlowLayoutPanel parent, string text, bool selected)
        {
            Button button = MakeButton(text, selected ? Color.FromArgb(232, 242, 255) : Color.White, selected ? Color.FromArgb(0, 99, 255) : Color.FromArgb(18, 43, 73));
            button.Width = 118;
            button.Tag = text;
            button.Click += (s, e) =>
            {
                selectedFilter = text;
                currentPage = 0;
                foreach (Control control in parent.Controls)
                {
                    if (control is Button filterButton)
                    {
                        bool active = string.Equals(filterButton.Tag as string, selectedFilter, StringComparison.OrdinalIgnoreCase);
                        filterButton.BackColor = active ? Color.FromArgb(232, 242, 255) : Color.White;
                        filterButton.ForeColor = active ? Color.FromArgb(0, 99, 255) : Color.FromArgb(18, 43, 73);
                    }
                }

                RenderAlerts();
            };
            parent.Controls.Add(button);
        }

        private static DataGridViewTextBoxColumn MakeTextColumn(string name, string header, int width, bool fill = false)
        {
            return new DataGridViewTextBoxColumn
            {
                Name = name,
                HeaderText = header,
                Width = width,
                AutoSizeMode = fill ? DataGridViewAutoSizeColumnMode.Fill : DataGridViewAutoSizeColumnMode.None
            };
        }

        private static Label AddHeaderStat(TableLayoutPanel parent, int column, string icon, string title, Color color)
        {
            Panel card = new Panel { Dock = DockStyle.Fill, BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle, Padding = new Padding(10), Margin = new Padding(5, 0, 5, 8) };
            TableLayoutPanel layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 46));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            Label iconLabel = MakeLabel(icon, 18, FontStyle.Bold, color);
            iconLabel.TextAlign = ContentAlignment.MiddleCenter;
            layout.Controls.Add(iconLabel, 0, 0);

            TableLayoutPanel text = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 3, ColumnCount = 1 };
            text.RowStyles.Add(new RowStyle(SizeType.Percent, 34));
            text.RowStyles.Add(new RowStyle(SizeType.Percent, 38));
            text.RowStyles.Add(new RowStyle(SizeType.Percent, 28));
            Label caption = MakeLabel(title, 8, FontStyle.Regular, Color.FromArgb(95, 110, 130));
            Label number = MakeLabel("0", 15, FontStyle.Bold, color);
            Label note = MakeLabel(title == "Đã xác nhận" ? "Đã xử lý" : "Đang hoạt động", 7, FontStyle.Regular, Color.FromArgb(95, 110, 130));
            text.Controls.Add(caption, 0, 0);
            text.Controls.Add(number, 0, 1);
            text.Controls.Add(note, 0, 2);
            layout.Controls.Add(text, 1, 0);
            card.Controls.Add(layout);
            parent.Controls.Add(card, column, 0);
            return number;
        }

        private static Label AddMetric(TableLayoutPanel parent, int column, string title)
        {
            Panel card = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(248, 251, 255), Margin = new Padding(4), Padding = new Padding(8) };
            TableLayoutPanel layout = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2, ColumnCount = 1 };
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 45));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 55));
            Label label = MakeLabel(title, 7, FontStyle.Regular, Color.FromArgb(95, 110, 130));
            Label value = MakeLabel("--", 10, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            label.TextAlign = ContentAlignment.BottomCenter;
            value.TextAlign = ContentAlignment.TopCenter;
            layout.Controls.Add(label, 0, 0);
            layout.Controls.Add(value, 0, 1);
            card.Controls.Add(layout);
            parent.Controls.Add(card, column, 0);
            return value;
        }

        private static Label MakeBadge(string text, Color color)
        {
            Label badge = MakeLabel(text, 8, FontStyle.Bold, color);
            badge.BackColor = Lighten(color);
            badge.TextAlign = ContentAlignment.MiddleCenter;
            badge.Margin = new Padding(0, 16, 8, 16);
            return badge;
        }

        private static Button MakeButton(string text, Color backColor, Color foreColor)
        {
            Button button = new Button
            {
                Text = text,
                Height = 34,
                Width = 104,
                Margin = new Padding(5, 3, 5, 3),
                FlatStyle = FlatStyle.Flat,
                BackColor = backColor,
                ForeColor = foreColor,
                Font = new Font("Segoe UI", 8, FontStyle.Bold)
            };
            button.FlatAppearance.BorderColor = Color.FromArgb(205, 220, 242);
            return button;
        }

        private static Label MakeLabel(string text, int size, FontStyle style, Color color)
        {
            return new Label
            {
                Text = text,
                Dock = DockStyle.Fill,
                AutoSize = false,
                Font = new Font("Segoe UI", size, style),
                ForeColor = color
            };
        }

        private static Color GetLevelColor(string level)
        {
            return level == "Nguy cấp" ? Color.FromArgb(235, 54, 70) : Color.FromArgb(245, 132, 15);
        }

        private static Color Lighten(Color color)
        {
            return Color.FromArgb(
                255,
                Math.Min(255, color.R + 215),
                Math.Min(255, color.G + 225),
                Math.Min(255, color.B + 235));
        }

        private static string BuildMetricLine(AlertHistoryEntry alert)
        {
            return $"SpO₂ {FormatPercent(alert.Spo2)} | Tim {FormatNumber(alert.HeartRate)} | Nhiệt {FormatTemperature(alert.Temperature)} | Nhỏ giọt {FormatDrip(alert.DripRate)}";
        }

        private static string FormatPercent(int? value) => value.HasValue ? value.Value + "%" : "--";

        private static string FormatNumber(int? value) => value.HasValue ? value.Value.ToString() : "--";

        private static string FormatTemperature(decimal? value) => value.HasValue ? value.Value.ToString("0.0") + " °C" : "--";

        private static string FormatDrip(int? value) => value.HasValue ? value.Value + "/phút" : "--";
    }
}
