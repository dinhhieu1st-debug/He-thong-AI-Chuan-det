using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace Server
{
    public sealed class ApiServer : IDisposable
    {
        private readonly int port;
        private readonly Func<IReadOnlyList<BedData>> getBeds;
        private readonly Func<IReadOnlyList<AlertData>> getAlerts;
        private readonly Action<string> acknowledgeAlert;
        private readonly Action<string> registerMobileToken;
        private readonly Action<string> reportStatus;
        private readonly CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
        private readonly JsonSerializerOptions jsonOptions = new JsonSerializerOptions
        {
            WriteIndented = true
        };

        private HttpListener? listener;
        private Task? listenTask;
        private string activePrefix = string.Empty;

        public ApiServer(
            int port,
            Func<IReadOnlyList<BedData>> getBeds,
            Func<IReadOnlyList<AlertData>> getAlerts,
            Action<string> acknowledgeAlert,
            Action<string> registerMobileToken,
            Action<string> reportStatus)
        {
            this.port = port;
            this.getBeds = getBeds;
            this.getAlerts = getAlerts;
            this.acknowledgeAlert = acknowledgeAlert;
            this.registerMobileToken = registerMobileToken;
            this.reportStatus = reportStatus;
        }

        public void Start()
        {
            if (listenTask != null)
            {
                return;
            }

            listener = new HttpListener();

            try
            {
                activePrefix = $"http://+:{port}/";
                listener.Prefixes.Add(activePrefix);
                listener.Start();
            }
            catch (HttpListenerException ex) when (ex.ErrorCode == 5)
            {
                listener.Close();
                listener = new HttpListener();
                activePrefix = $"http://localhost:{port}/";
                listener.Prefixes.Add(activePrefix);

                try
                {
                    listener.Start();
                    reportStatus($"HTTP API chỉ chạy localhost:{port} do thiếu quyền http://+:{port}/. Chạy app bằng Administrator hoặc cấp URL ACL để Android truy cập LAN.");
                }
                catch (Exception fallbackEx)
                {
                    reportStatus("Lỗi mở HTTP API: " + fallbackEx.Message);
                    return;
                }
            }
            catch (Exception ex)
            {
                reportStatus("Lỗi mở HTTP API: " + ex.Message);
                return;
            }

            if (!activePrefix.StartsWith("http://localhost", StringComparison.OrdinalIgnoreCase))
            {
                reportStatus($"HTTP API đang chạy: {activePrefix}");
            }

            listenTask = Task.Run(() => ListenAsync(cancellationTokenSource.Token));
        }

        public void Dispose()
        {
            cancellationTokenSource.Cancel();
            try
            {
                listener?.Stop();
                listener?.Close();
            }
            catch
            {
            }
            cancellationTokenSource.Dispose();
        }

        private async Task ListenAsync(CancellationToken cancellationToken)
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                try
                {
                    if (listener == null)
                    {
                        return;
                    }

                    HttpListenerContext context = await listener.GetContextAsync();
                    _ = Task.Run(() => HandleRequestAsync(context), cancellationToken);
                }
                catch (ObjectDisposedException)
                {
                    return;
                }
                catch (HttpListenerException)
                {
                    return;
                }
                catch (Exception ex)
                {
                    reportStatus("Lỗi HTTP API: " + ex.Message);
                }
            }
        }

        private async Task HandleRequestAsync(HttpListenerContext context)
        {
            try
            {
                AddCorsHeaders(context.Response);

                if (context.Request.HttpMethod == "OPTIONS")
                {
                    context.Response.StatusCode = 204;
                    context.Response.Close();
                    return;
                }

                string path = context.Request.Url?.AbsolutePath.TrimEnd('/') ?? string.Empty;
                string method = context.Request.HttpMethod.ToUpperInvariant();

                if (method == "GET" && path.Equals("/api/beds", StringComparison.OrdinalIgnoreCase))
                {
                    await WriteJsonAsync(context.Response, CreateBedResponse());
                    return;
                }

                if (method == "GET" && path.Equals("/api/alerts", StringComparison.OrdinalIgnoreCase))
                {
                    await WriteJsonAsync(context.Response, CreateAlertResponse());
                    return;
                }

                if (method == "POST" && path.StartsWith("/api/alerts/", StringComparison.OrdinalIgnoreCase) && path.EndsWith("/ack", StringComparison.OrdinalIgnoreCase))
                {
                    string id = ExtractAlertId(path);
                    if (string.IsNullOrWhiteSpace(id))
                    {
                        await WriteErrorAsync(context.Response, 400, "Missing alert id");
                        return;
                    }

                    acknowledgeAlert(WebUtility.UrlDecode(id));
                    await WriteJsonAsync(context.Response, new { ok = true });
                    return;
                }

                if (method == "POST" && path.Equals("/api/mobile/register-token", StringComparison.OrdinalIgnoreCase))
                {
                    string body = await ReadRequestBodyAsync(context.Request);
                    using JsonDocument document = JsonDocument.Parse(body);
                    string token = document.RootElement.TryGetProperty("token", out JsonElement tokenElement)
                        ? tokenElement.GetString() ?? string.Empty
                        : string.Empty;

                    if (string.IsNullOrWhiteSpace(token))
                    {
                        await WriteErrorAsync(context.Response, 400, "Missing FCM token");
                        return;
                    }

                    registerMobileToken(token);
                    await WriteJsonAsync(context.Response, new { ok = true });
                    return;
                }

                await WriteErrorAsync(context.Response, 404, "Not found");
            }
            catch (Exception ex)
            {
                await WriteErrorAsync(context.Response, 500, ex.Message);
            }
        }

        private IEnumerable<object> CreateBedResponse()
        {
            return getBeds().Select(bed => new
            {
                bedId = bed.MaGiuong,
                room = bed.Phong,
                spo2 = bed.Spo2,
                heartRate = bed.NhipTim,
                temperature = bed.NhietDo,
                dripRate = bed.TocDoNhoGiot,
                status = bed.TrangThai,
                lastUpdated = bed.ThoiGianCapNhat.ToString("yyyy-MM-ddTHH:mm:ss")
            });
        }

        private IEnumerable<object> CreateAlertResponse()
        {
            return getAlerts()
                .Where(alert => !alert.Acknowledged)
                .Select(alert => new
                {
                    id = alert.Id,
                    bedId = alert.BedId,
                    room = alert.Room,
                    level = alert.Level,
                    message = alert.Message,
                    spo2 = alert.Spo2,
                    heartRate = alert.HeartRate,
                    temperature = alert.Temperature,
                    dripRate = alert.DripRate,
                    createdAt = alert.CreatedAt.ToString("yyyy-MM-ddTHH:mm:ss"),
                    acknowledged = alert.Acknowledged
                });
        }

        private static string ExtractAlertId(string path)
        {
            string trimmed = path.Trim('/');
            string[] parts = trimmed.Split('/');
            return parts.Length == 4 ? parts[2] : string.Empty;
        }

        private async Task WriteJsonAsync(HttpListenerResponse response, object value)
        {
            string json = JsonSerializer.Serialize(value, jsonOptions);
            byte[] buffer = Encoding.UTF8.GetBytes(json);
            response.StatusCode = 200;
            response.ContentType = "application/json; charset=utf-8";
            response.ContentEncoding = Encoding.UTF8;
            response.ContentLength64 = buffer.Length;
            await response.OutputStream.WriteAsync(buffer, 0, buffer.Length);
            response.Close();
        }

        private static async Task<string> ReadRequestBodyAsync(HttpListenerRequest request)
        {
            using StreamReader reader = new StreamReader(request.InputStream, request.ContentEncoding ?? Encoding.UTF8);
            return await reader.ReadToEndAsync();
        }

        private async Task WriteErrorAsync(HttpListenerResponse response, int statusCode, string message)
        {
            string json = JsonSerializer.Serialize(new { error = message }, jsonOptions);
            byte[] buffer = Encoding.UTF8.GetBytes(json);
            response.StatusCode = statusCode;
            response.ContentType = "application/json; charset=utf-8";
            response.ContentEncoding = Encoding.UTF8;
            response.ContentLength64 = buffer.Length;
            await response.OutputStream.WriteAsync(buffer, 0, buffer.Length);
            response.Close();
        }

        private static void AddCorsHeaders(HttpListenerResponse response)
        {
            response.Headers["Access-Control-Allow-Origin"] = "*";
            response.Headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS";
            response.Headers["Access-Control-Allow-Headers"] = "Content-Type";
        }
    }

    public sealed class AlertData
    {
        public AlertData(
            string id,
            string bedId,
            string room,
            string level,
            string message,
            int spo2,
            int heartRate,
            double temperature,
            int dripRate,
            DateTime createdAt)
        {
            Id = id;
            BedId = bedId;
            Room = room;
            Level = level;
            Message = message;
            Spo2 = spo2;
            HeartRate = heartRate;
            Temperature = temperature;
            DripRate = dripRate;
            CreatedAt = createdAt;
        }

        public string Id { get; }
        public string BedId { get; }
        public string Room { get; }
        public string Level { get; }
        public string Message { get; }
        public int Spo2 { get; }
        public int HeartRate { get; }
        public double Temperature { get; }
        public int DripRate { get; }
        public DateTime CreatedAt { get; }
        public bool Acknowledged { get; set; }
    }
}
