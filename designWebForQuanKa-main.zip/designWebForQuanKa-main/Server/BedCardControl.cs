using System;
using System.Drawing;
using System.Windows.Forms;

namespace Server
{
    public sealed class BedCardControl : UserControl
    {
        private readonly Panel statusBar;
        private readonly Label lblBed;
        private readonly Label lblRoom;
        private readonly Label lblStatus;
        private readonly Label lblSpo2;
        private readonly Label lblHeartRate;
        private readonly Label lblTemperature;
        private readonly Label lblDripRate;
        private readonly Label lblConnection;
        private readonly Label lblUpdated;
        private readonly Button btnDetail;

        public event EventHandler<BedData>? DetailRequested;

        public BedData? Data { get; private set; }

        public BedCardControl()
        {
            Height = 186;
            Width = 300;
            Margin = new Padding(8);
            BackColor = Color.White;
            BorderStyle = BorderStyle.FixedSingle;

            statusBar = new Panel
            {
                Dock = DockStyle.Top,
                Height = 4,
                BackColor = Color.FromArgb(36, 123, 230)
            };
            Controls.Add(statusBar);

            TableLayoutPanel root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(14, 10, 14, 10),
                RowCount = 3,
                ColumnCount = 1
            };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 86));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            Controls.Add(root);

            TableLayoutPanel header = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 3,
                RowCount = 1
            };
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 42));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 84));

            Label icon = new Label
            {
                Text = "▭",
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI Symbol", 18, FontStyle.Bold),
                ForeColor = Color.FromArgb(0, 99, 255),
                TextAlign = ContentAlignment.MiddleCenter
            };
            header.Controls.Add(icon, 0, 0);

            TableLayoutPanel titleBlock = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 2,
                ColumnCount = 1
            };
            titleBlock.RowStyles.Add(new RowStyle(SizeType.Percent, 58));
            titleBlock.RowStyles.Add(new RowStyle(SizeType.Percent, 42));

            lblBed = MakeLabel("Giường --", 10, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            lblRoom = MakeLabel("Phòng --", 8, FontStyle.Regular, Color.FromArgb(85, 99, 118));
            lblBed.TextAlign = ContentAlignment.BottomLeft;
            lblRoom.TextAlign = ContentAlignment.TopLeft;
            titleBlock.Controls.Add(lblBed, 0, 0);
            titleBlock.Controls.Add(lblRoom, 0, 1);
            header.Controls.Add(titleBlock, 1, 0);

            lblStatus = MakeLabel("--", 7, FontStyle.Bold, Color.Gray);
            lblStatus.Dock = DockStyle.Fill;
            lblStatus.Margin = new Padding(4, 9, 0, 9);
            lblStatus.TextAlign = ContentAlignment.MiddleCenter;
            lblStatus.BackColor = Color.FromArgb(244, 247, 251);
            header.Controls.Add(lblStatus, 2, 0);
            root.Controls.Add(header, 0, 0);

            TableLayoutPanel vitals = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 4,
                RowCount = 1
            };
            for (int i = 0; i < 4; i++)
            {
                vitals.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
            }

            lblSpo2 = AddMetric(vitals, 0, "♢", "SpO₂");
            lblHeartRate = AddMetric(vitals, 1, "♡", "Nhịp tim");
            lblTemperature = AddMetric(vitals, 2, "♨", "Nhiệt độ");
            lblDripRate = AddMetric(vitals, 3, "♢", "Nhỏ giọt");
            root.Controls.Add(vitals, 0, 1);

            TableLayoutPanel footer = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 3,
                RowCount = 1
            };
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 32));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 68));

            lblConnection = MakeLabel("◷ Đang chờ", 8, FontStyle.Regular, Color.FromArgb(85, 99, 118));
            lblUpdated = MakeLabel("--:--:--", 7, FontStyle.Regular, Color.FromArgb(85, 99, 118));
            lblConnection.TextAlign = ContentAlignment.MiddleLeft;
            lblUpdated.TextAlign = ContentAlignment.MiddleCenter;

            btnDetail = new Button
            {
                Text = "Chi tiết ›",
                Dock = DockStyle.Fill,
                Margin = new Padding(5, 5, 0, 0),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 7, FontStyle.Bold),
                ForeColor = Color.FromArgb(0, 99, 255),
                BackColor = Color.White
            };
            btnDetail.FlatAppearance.BorderColor = Color.FromArgb(205, 220, 242);
            btnDetail.Click += (s, e) =>
            {
                if (Data != null)
                {
                    DetailRequested?.Invoke(this, Data);
                }
            };

            footer.Controls.Add(lblConnection, 0, 0);
            footer.Controls.Add(lblUpdated, 1, 0);
            footer.Controls.Add(btnDetail, 2, 0);
            root.Controls.Add(footer, 0, 2);
        }

        public void SetData(BedData data)
        {
            Data = data;
            Color statusColor = GetStatusColor(data.TrangThai);

            statusBar.BackColor = statusColor;
            lblBed.Text = data.MaGiuong;
            lblRoom.Text = data.Phong;
            lblStatus.Text = data.TrangThai;
            lblStatus.ForeColor = statusColor;
            lblStatus.BackColor = Lighten(statusColor);

            if (data.TrangThai == "NGOẠI TUYẾN")
            {
                lblConnection.Text = "● Mất kết nối";
                lblConnection.ForeColor = Color.FromArgb(100, 112, 130);
            }
            else
            {
                lblConnection.Text = "● Trực tuyến";
                lblConnection.ForeColor = Color.FromArgb(0, 150, 84);
            }

            lblSpo2.Text = data.Spo2 > 0 ? data.Spo2 + "%" : "--";
            lblSpo2.ForeColor = data.Spo2 > 0 ? GetSpo2Color(data.Spo2) : Color.FromArgb(105, 118, 135);
            lblHeartRate.Text = data.NhipTim > 0 ? data.NhipTim + " bpm" : "--";
            lblHeartRate.ForeColor = data.NhipTim > 0 ? GetHeartRateColor(data.NhipTim) : Color.FromArgb(105, 118, 135);
            lblTemperature.Text = data.NhietDo > 0 ? data.NhietDo.ToString("0.0") + " °C" : "--";
            lblTemperature.ForeColor = data.NhietDo > 0 ? GetTemperatureColor(data.NhietDo) : Color.FromArgb(105, 118, 135);
            lblDripRate.Text = data.TocDoNhoGiot > 0 ? data.TocDoNhoGiot + " /phút" : "--";
            lblDripRate.ForeColor = data.TocDoNhoGiot > 0 ? Color.FromArgb(0, 150, 84) : Color.FromArgb(105, 118, 135);
            lblUpdated.Text = "Cập nhật: " + data.ThoiGianCapNhat.ToString("HH:mm:ss");
        }

        private static Label AddMetric(TableLayoutPanel parent, int column, string icon, string name)
        {
            Panel box = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(248, 251, 255),
                Margin = new Padding(4, 8, 4, 8),
                Padding = new Padding(3)
            };

            TableLayoutPanel metric = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 2,
                ColumnCount = 1
            };
            metric.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));
            metric.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            Label title = MakeLabel(icon + "  " + name, 6, FontStyle.Regular, Color.FromArgb(74, 90, 112));
            title.TextAlign = ContentAlignment.BottomCenter;

            Label value = MakeLabel("--", 10, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            value.TextAlign = ContentAlignment.TopCenter;

            metric.Controls.Add(title, 0, 0);
            metric.Controls.Add(value, 0, 1);
            box.Controls.Add(metric);
            parent.Controls.Add(box, column, 0);
            return value;
        }

        private static Label MakeLabel(string text, int size, FontStyle style, Color color)
        {
            return new Label
            {
                Text = text,
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", size, style),
                ForeColor = color,
                AutoSize = false
            };
        }

        private static Color GetStatusColor(string status)
        {
            if (status == "NGUY CẤP")
            {
                return Color.FromArgb(235, 54, 70);
            }

            if (status == "CẢNH BÁO")
            {
                return Color.FromArgb(245, 132, 15);
            }

            if (status == "ỔN ĐỊNH")
            {
                return Color.FromArgb(0, 150, 84);
            }

            return Color.FromArgb(105, 118, 135);
        }

        private static Color GetSpo2Color(int value)
        {
            if (value < 90)
            {
                return Color.FromArgb(235, 54, 70);
            }

            if (value < 95)
            {
                return Color.FromArgb(245, 132, 15);
            }

            return Color.FromArgb(0, 150, 84);
        }

        private static Color GetHeartRateColor(int value)
        {
            if (value < 60 || value > 110)
            {
                return Color.FromArgb(235, 54, 70);
            }

            return Color.FromArgb(0, 150, 84);
        }

        private static Color GetTemperatureColor(double value)
        {
            if (value >= 38)
            {
                return Color.FromArgb(235, 54, 70);
            }

            if (value >= 37.5)
            {
                return Color.FromArgb(245, 132, 15);
            }

            return Color.FromArgb(0, 150, 84);
        }

        private static Color Lighten(Color color)
        {
            return Color.FromArgb(
                245,
                Math.Min(255, color.R + 235) / 2,
                Math.Min(255, color.G + 245) / 2,
                Math.Min(255, color.B + 255) / 2);
        }
    }
}
