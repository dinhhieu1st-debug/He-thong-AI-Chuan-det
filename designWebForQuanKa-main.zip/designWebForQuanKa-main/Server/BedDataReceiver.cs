﻿using System;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace Server
{
    public sealed class BedDataReceiver : IDisposable
    {
        private readonly int congNhanDuLieu;
        private readonly CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
        private TcpListener? tcpListener;
        private Task? listeningTask;

        public BedDataReceiver(int congNhanDuLieu)
        {
            this.congNhanDuLieu = congNhanDuLieu;
        }

        public event EventHandler<BedData>? DataReceived;
        public event EventHandler<string>? ErrorOccurred;

        public void Start()
        {
            if (listeningTask != null)
            {
                return;
            }

            tcpListener = new TcpListener(IPAddress.Any, congNhanDuLieu);
            tcpListener.Start();
            listeningTask = Task.Run(() => ListenAsync(cancellationTokenSource.Token));
        }

        public void Dispose()
        {
            cancellationTokenSource.Cancel();
            tcpListener?.Stop();
            cancellationTokenSource.Dispose();
        }

        private async Task ListenAsync(CancellationToken cancellationToken)
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                try
                {
                    if (tcpListener == null)
                    {
                        return;
                    }

                    TcpClient client = await tcpListener.AcceptTcpClientAsync(cancellationToken);
                    _ = Task.Run(() => ReadClientAsync(client, cancellationToken), cancellationToken);
                }
                catch (OperationCanceledException)
                {
                    return;
                }
                catch (Exception ex)
                {
                    ErrorOccurred?.Invoke(this, "Lỗi mở cổng nhận dữ liệu: " + ex.Message);
                }
            }
        }

        private async Task ReadClientAsync(TcpClient client, CancellationToken cancellationToken)
        {
            using (client)
            using (NetworkStream stream = client.GetStream())
            using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
            {
                while (!cancellationToken.IsCancellationRequested)
                {
                    string? json = await reader.ReadLineAsync(cancellationToken);
                    if (json == null)
                    {
                        return;
                    }

                    if (string.IsNullOrWhiteSpace(json))
                    {
                        continue;
                    }

                    try
                    {
                        BedData duLieu = ParseJson(json);
                        DataReceived?.Invoke(this, duLieu);
                    }
                    catch (Exception ex)
                    {
                        ErrorOccurred?.Invoke(this, "JSON không hợp lệ: " + ex.Message);
                    }
                }
            }
        }

        private static BedData ParseJson(string json)
        {
            using JsonDocument document = JsonDocument.Parse(json);
            JsonElement root = document.RootElement;

            string maGiuong = ReadString(root, "maGiuong", "bedId", "bed_id", "bed", "giuong") ?? "Giường 01";
            string phong = ReadString(root, "phong", "room") ?? "Chưa rõ phòng";
            string trangThai = ReadString(root, "trangThai", "status") ?? string.Empty;
            string moTaCanhBao = ReadString(root, "moTaCanhBao", "alertMessage", "alert_message") ?? string.Empty;
            int spo2 = ReadInt(root, 0, "spo2", "SpO2", "SpO₂");
            int nhipTim = ReadInt(root, 0, "nhipTim", "heartRate", "heart_rate", "bpm");
            double nhietDo = ReadDouble(root, 0, "nhietDo", "temperature", "temp");
            int tocDoNhoGiot = ReadInt(root, 0, "tocDoNhoGiot", "dripRate", "drip_rate", "dropRate");

            return new BedData(maGiuong, phong, trangThai, spo2, nhipTim, nhietDo, tocDoNhoGiot, DateTime.Now, moTaCanhBao);
        }

        private static string? ReadString(JsonElement root, params string[] names)
        {
            foreach (string name in names)
            {
                if (TryGetProperty(root, name, out JsonElement property))
                {
                    return property.ValueKind == JsonValueKind.String ? property.GetString() : property.ToString();
                }
            }

            return null;
        }

        private static int ReadInt(JsonElement root, int defaultValue, params string[] names)
        {
            foreach (string name in names)
            {
                if (!TryGetProperty(root, name, out JsonElement property))
                {
                    continue;
                }

                if (property.ValueKind == JsonValueKind.Number && property.TryGetInt32(out int value))
                {
                    return value;
                }

                if (int.TryParse(property.ToString(), NumberStyles.Integer, CultureInfo.InvariantCulture, out value))
                {
                    return value;
                }
            }

            return defaultValue;
        }

        private static double ReadDouble(JsonElement root, double defaultValue, params string[] names)
        {
            foreach (string name in names)
            {
                if (!TryGetProperty(root, name, out JsonElement property))
                {
                    continue;
                }

                if (property.ValueKind == JsonValueKind.Number && property.TryGetDouble(out double value))
                {
                    return value;
                }

                if (double.TryParse(property.ToString(), NumberStyles.Float, CultureInfo.InvariantCulture, out value))
                {
                    return value;
                }
            }

            return defaultValue;
        }

        private static bool TryGetProperty(JsonElement root, string name, out JsonElement property)
        {
            foreach (JsonProperty jsonProperty in root.EnumerateObject())
            {
                if (string.Equals(jsonProperty.Name, name, StringComparison.OrdinalIgnoreCase))
                {
                    property = jsonProperty.Value;
                    return true;
                }
            }

            property = default;
            return false;
        }
    }

    public sealed record BedData(
        string MaGiuong,
        string Phong,
        string TrangThai,
        int Spo2,
        int NhipTim,
        double NhietDo,
        int TocDoNhoGiot,
        DateTime ThoiGianCapNhat,
        string MoTaCanhBao = "")
    {
        public BedData WithStatus(string trangThai)
        {
            return this with { TrangThai = trangThai };
        }
    }
}
