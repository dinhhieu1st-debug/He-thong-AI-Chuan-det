using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Server
{
    public sealed class BedManagementView : UserControl
    {
        private TextBox txtSearch = null!;
        private FlowLayoutPanel roomFilters = null!;
        private FlowLayoutPanel statusFilters = null!;
        private FlowLayoutPanel bedGrid = null!;
        private Label lblQuickBed = null!;
        private Label lblQuickRoom = null!;
        private Label lblQuickCode = null!;
        private Label lblQuickDevice = null!;
        private Label lblQuickUsage = null!;
        private Label lblQuickConnection = null!;
        private Label lblQuickUpdated = null!;
        private FlowLayoutPanel quickAlerts = null!;
        private Button btnSaveInterval = null!;
        private readonly Dictionary<string, BedData> beds = new Dictionary<string, BedData>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, BedCardControl> cards = new Dictionary<string, BedCardControl>(StringComparer.OrdinalIgnoreCase);

        private string selectedRoom = "Tất cả";
        private string selectedStatus = "Tất cả";

        public event EventHandler? SaveIntervalRequested;

        public BedManagementView()
        {
            Dock = DockStyle.Fill;
            BackColor = Color.FromArgb(244, 248, 253);

            TableLayoutPanel root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 3,
                Padding = new Padding(22, 16, 16, 16)
            };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 72));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 92));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            Controls.Add(root);

            root.Controls.Add(CreateHeader(), 0, 0);
            root.Controls.Add(CreateFilters(), 0, 1);
            root.Controls.Add(CreateContent(), 0, 2);

            Resize += (s, e) => ResizeCards();
        }

        public void UpsertBed(BedData data)
        {
            beds[data.MaGiuong] = data;

            if (!cards.TryGetValue(data.MaGiuong, out BedCardControl? card))
            {
                card = new BedCardControl();
                card.DetailRequested += (s, bed) => ShowQuickInfo(bed);
                cards[data.MaGiuong] = card;
                bedGrid.Controls.Add(card);
            }

            card.SetData(data);
            RenderRoomFilters();
            ApplyFilters();

            if (lblQuickBed.Tag is string activeBed && string.Equals(activeBed, data.MaGiuong, StringComparison.OrdinalIgnoreCase))
            {
                ShowQuickInfo(data);
            }
            else if (lblQuickBed.Tag == null)
            {
                ShowQuickInfo(data);
            }
        }

        public IReadOnlyList<BedData> CurrentBeds()
        {
            return beds.Values.ToList();
        }

        public void RefreshView()
        {
            RenderRoomFilters();
            ApplyFilters();
        }

        public void SetSaveInterval(int seconds)
        {
            btnSaveInterval.Text = $"⚙  Lưu SQL: {seconds}s";
        }

        public void MarkOffline(BedData data)
        {
            UpsertBed(data.WithStatus("NGOẠI TUYẾN"));
        }

        private Control CreateHeader()
        {
            TableLayoutPanel header = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 1
            };
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 440));

            TableLayoutPanel titleBlock = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 2,
                ColumnCount = 1
            };
            titleBlock.RowStyles.Add(new RowStyle(SizeType.Percent, 58));
            titleBlock.RowStyles.Add(new RowStyle(SizeType.Percent, 42));

            Label title = MakeLabel("QUẢN LÝ GIƯỜNG BỆNH", 20, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            title.TextAlign = ContentAlignment.BottomLeft;

            Label subtitle = MakeLabel("Theo dõi trạng thái giường, phòng và chỉ số sinh tồn", 9, FontStyle.Regular, Color.FromArgb(95, 110, 130));
            subtitle.TextAlign = ContentAlignment.TopLeft;

            titleBlock.Controls.Add(title, 0, 0);
            titleBlock.Controls.Add(subtitle, 0, 1);
            header.Controls.Add(titleBlock, 0, 0);

            FlowLayoutPanel actions = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.RightToLeft,
                WrapContents = false,
                Padding = new Padding(0, 6, 0, 12)
            };
            Button add = MakeButton("＋  Thêm giường", Color.FromArgb(0, 99, 255), Color.White);
            add.Width = 142;
            Button refresh = MakeButton("⟳  Làm mới", Color.White, Color.FromArgb(18, 62, 112));
            refresh.Width = 120;
            refresh.Click += (s, e) => ApplyFilters();
            btnSaveInterval = MakeButton("⚙  Lưu SQL: 10s", Color.White, Color.FromArgb(18, 62, 112));
            btnSaveInterval.Width = 142;
            btnSaveInterval.Click += (s, e) => SaveIntervalRequested?.Invoke(this, EventArgs.Empty);
            actions.Controls.Add(refresh);
            actions.Controls.Add(btnSaveInterval);
            actions.Controls.Add(add);
            header.Controls.Add(actions, 1, 0);

            return header;
        }

        private Control CreateFilters()
        {
            TableLayoutPanel filters = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 2
            };
            filters.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
            filters.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));

            FlowLayoutPanel top = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false
            };
            txtSearch = new TextBox
            {
                Width = 290,
                Height = 32,
                Font = new Font("Segoe UI", 9),
                PlaceholderText = "Tìm theo mã giường, phòng..."
            };
            txtSearch.TextChanged += (s, e) => ApplyFilters();
            top.Controls.Add(txtSearch);

            roomFilters = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false
            };
            roomFilters.Controls.Add(MakeFilterButton("▦  Tất cả", "Tất cả", true, value =>
            {
                selectedRoom = value;
                ApplyFilters();
            }));

            filters.Controls.Add(top, 0, 0);
            filters.Controls.Add(roomFilters, 0, 1);

            statusFilters = new FlowLayoutPanel
            {
                Dock = DockStyle.Bottom,
                Height = 40,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false
            };

            statusFilters.Controls.Add(MakeFilterButton("●  Đang dùng", "ỔN ĐỊNH", false, value =>
            {
                selectedStatus = value;
                ApplyFilters();
            }));
            statusFilters.Controls.Add(MakeFilterButton("▭  Trống", "TRỐNG", false, value =>
            {
                selectedStatus = value;
                ApplyFilters();
            }));
            statusFilters.Controls.Add(MakeFilterButton("⚠  Cảnh báo", "CẢNH BÁO", false, value =>
            {
                selectedStatus = value;
                ApplyFilters();
            }));
            statusFilters.Controls.Add(MakeFilterButton("⌁  Ngoại tuyến", "NGOẠI TUYẾN", false, value =>
            {
                selectedStatus = value;
                ApplyFilters();
            }));

            top.Controls.Add(statusFilters);
            return filters;
        }

        private Control CreateContent()
        {
            TableLayoutPanel content = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 1
            };
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 72));
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 28));

            bedGrid = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true,
                WrapContents = true,
                BackColor = Color.FromArgb(244, 248, 253),
                Padding = new Padding(0, 4, 6, 6)
            };
            bedGrid.Resize += (s, e) => ResizeCards();
            content.Controls.Add(bedGrid, 0, 0);
            content.Controls.Add(CreateQuickInfoPanel(), 1, 0);
            return content;
        }

        private Control CreateQuickInfoPanel()
        {
            Panel panel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Padding = new Padding(16),
                Margin = new Padding(10, 4, 0, 8)
            };

            TableLayoutPanel root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 4,
                ColumnCount = 1
            };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 44));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 78));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 142));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            panel.Controls.Add(root);

            Label title = MakeLabel("THÔNG TIN NHANH", 9, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            title.TextAlign = ContentAlignment.MiddleLeft;
            root.Controls.Add(title, 0, 0);

            TableLayoutPanel bedTitle = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 1
            };
            bedTitle.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 48));
            bedTitle.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            Label icon = MakeLabel("▭", 20, FontStyle.Bold, Color.FromArgb(0, 99, 255));
            icon.TextAlign = ContentAlignment.MiddleCenter;
            bedTitle.Controls.Add(icon, 0, 0);

            TableLayoutPanel bedText = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2, ColumnCount = 1 };
            bedText.RowStyles.Add(new RowStyle(SizeType.Percent, 58));
            bedText.RowStyles.Add(new RowStyle(SizeType.Percent, 42));
            lblQuickBed = MakeLabel("Chưa chọn giường", 11, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            lblQuickRoom = MakeLabel("--", 8, FontStyle.Regular, Color.FromArgb(95, 110, 130));
            lblQuickBed.TextAlign = ContentAlignment.BottomLeft;
            lblQuickRoom.TextAlign = ContentAlignment.TopLeft;
            bedText.Controls.Add(lblQuickBed, 0, 0);
            bedText.Controls.Add(lblQuickRoom, 0, 1);
            bedTitle.Controls.Add(bedText, 1, 0);
            root.Controls.Add(bedTitle, 0, 1);

            TableLayoutPanel details = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 5,
                Padding = new Padding(0, 8, 0, 0)
            };
            details.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            details.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            for (int i = 0; i < 5; i++)
            {
                details.RowStyles.Add(new RowStyle(SizeType.Percent, 20));
            }

            lblQuickCode = AddDetail(details, 0, "Mã giường", "--");
            lblQuickDevice = AddDetail(details, 1, "Mã thiết bị", "xG26");
            lblQuickUsage = AddDetail(details, 2, "Trạng thái sử dụng", "--");
            lblQuickConnection = AddDetail(details, 3, "Trạng thái kết nối", "--");
            lblQuickUpdated = AddDetail(details, 4, "Thời gian cập nhật", "--");
            root.Controls.Add(details, 0, 2);

            Panel alertBox = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Padding = new Padding(10),
                Margin = new Padding(0, 8, 0, 0)
            };
            TableLayoutPanel alertRoot = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2, ColumnCount = 1 };
            alertRoot.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));
            alertRoot.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            alertBox.Controls.Add(alertRoot);

            Label alertTitle = MakeLabel("CẢNH BÁO HIỆN TẠI", 8, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            alertTitle.TextAlign = ContentAlignment.MiddleLeft;
            alertRoot.Controls.Add(alertTitle, 0, 0);

            quickAlerts = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                AutoScroll = true
            };
            alertRoot.Controls.Add(quickAlerts, 0, 1);
            root.Controls.Add(alertBox, 0, 3);

            return panel;
        }

        private void ShowQuickInfo(BedData data)
        {
            lblQuickBed.Tag = data.MaGiuong;
            lblQuickBed.Text = data.MaGiuong;
            lblQuickRoom.Text = data.Phong;
            lblQuickCode.Text = data.MaGiuong.Replace("Giường ", "BED-");
            lblQuickDevice.Text = "xG26";
            lblQuickUsage.Text = data.TrangThai == "NGOẠI TUYẾN" ? "Chưa xác định" : "Đang dùng";
            lblQuickUsage.ForeColor = data.TrangThai == "NGOẠI TUYẾN" ? Color.FromArgb(105, 118, 135) : Color.FromArgb(0, 150, 84);
            lblQuickConnection.Text = data.TrangThai == "NGOẠI TUYẾN" ? "Mất kết nối" : "Trực tuyến";
            lblQuickConnection.ForeColor = data.TrangThai == "NGOẠI TUYẾN" ? Color.FromArgb(105, 118, 135) : Color.FromArgb(0, 150, 84);
            lblQuickUpdated.Text = data.ThoiGianCapNhat.ToString("HH:mm:ss  dd/MM/yyyy");

            quickAlerts.Controls.Clear();
            foreach (string alert in BuildAlerts(data))
            {
                Label row = MakeLabel(alert, 8, FontStyle.Regular, Color.FromArgb(235, 54, 70));
                row.Height = 28;
                row.Width = Math.Max(220, quickAlerts.ClientSize.Width - 8);
                row.TextAlign = ContentAlignment.MiddleLeft;
                quickAlerts.Controls.Add(row);
            }

            if (quickAlerts.Controls.Count == 0)
            {
                Label empty = MakeLabel("Không có cảnh báo hiện tại", 8, FontStyle.Regular, Color.FromArgb(95, 110, 130));
                empty.Height = 28;
                empty.Width = Math.Max(220, quickAlerts.ClientSize.Width - 8);
                quickAlerts.Controls.Add(empty);
            }
        }

        private void ApplyFilters()
        {
            string keyword = txtSearch.Text.Trim();
            foreach (KeyValuePair<string, BedCardControl> item in cards)
            {
                BedData data = beds[item.Key];
                bool matchKeyword = string.IsNullOrWhiteSpace(keyword)
                    || data.MaGiuong.Contains(keyword, StringComparison.OrdinalIgnoreCase)
                    || data.Phong.Contains(keyword, StringComparison.OrdinalIgnoreCase);
                bool matchRoom = selectedRoom == "Tất cả" || string.Equals(data.Phong, selectedRoom, StringComparison.OrdinalIgnoreCase);
                bool matchStatus = selectedStatus == "Tất cả" || string.Equals(data.TrangThai, selectedStatus, StringComparison.OrdinalIgnoreCase);
                item.Value.Visible = matchKeyword && matchRoom && matchStatus;
            }

            ResizeCards();
        }

        private void RenderRoomFilters()
        {
            string previous = selectedRoom;
            roomFilters.Controls.Clear();
            roomFilters.Controls.Add(MakeFilterButton("▦  Tất cả", "Tất cả", selectedRoom == "Tất cả", value =>
            {
                selectedRoom = value;
                ApplyFilters();
            }));

            foreach (string room in beds.Values.Select(x => x.Phong).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct().OrderBy(x => x))
            {
                roomFilters.Controls.Add(MakeFilterButton("▤  " + room, room, string.Equals(selectedRoom, room, StringComparison.OrdinalIgnoreCase), value =>
                {
                    selectedRoom = value;
                    ApplyFilters();
                }));
            }

            if (previous != "Tất cả" && !beds.Values.Any(x => string.Equals(x.Phong, previous, StringComparison.OrdinalIgnoreCase)))
            {
                selectedRoom = "Tất cả";
            }
        }

        private void ResizeCards()
        {
            if (bedGrid.ClientSize.Width <= 0)
            {
                return;
            }

            int available = bedGrid.ClientSize.Width - bedGrid.Padding.Left - bedGrid.Padding.Right - SystemInformation.VerticalScrollBarWidth - 10;
            int columns = available >= 900 ? 3 : available >= 600 ? 2 : 1;
            int width = Math.Max(260, (available / columns) - 18);
            foreach (Control control in bedGrid.Controls)
            {
                control.Width = width;
            }
            bedGrid.PerformLayout();
        }

        private static IEnumerable<string> BuildAlerts(BedData data)
        {
            if (data.Spo2 > 0 && data.Spo2 < 90)
            {
                yield return "♢  SpO₂ thấp: " + data.Spo2 + "% (Ngưỡng: < 90%)";
            }

            if (data.NhipTim > 100)
            {
                yield return "♡  Nhịp tim cao: " + data.NhipTim + " bpm (Ngưỡng: > 100)";
            }
            else if (data.NhipTim > 0 && data.NhipTim < 60)
            {
                yield return "♡  Nhịp tim thấp: " + data.NhipTim + " bpm (Ngưỡng: < 60)";
            }

            if (data.NhietDo >= 38)
            {
                yield return "♨  Nhiệt độ cao: " + data.NhietDo.ToString("0.0") + " °C (Ngưỡng: > 38.0 °C)";
            }
        }

        private static Label AddDetail(TableLayoutPanel parent, int row, string label, string value)
        {
            Label left = MakeLabel(label, 8, FontStyle.Regular, Color.FromArgb(95, 110, 130));
            left.TextAlign = ContentAlignment.MiddleLeft;
            Label right = MakeLabel(value, 8, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            right.TextAlign = ContentAlignment.MiddleRight;
            parent.Controls.Add(left, 0, row);
            parent.Controls.Add(right, 1, row);
            return right;
        }

        private static Button MakeFilterButton(string text, string value, bool active, Action<string> onClick)
        {
            Button button = MakeButton(text, active ? Color.FromArgb(231, 241, 255) : Color.White, Color.FromArgb(18, 62, 112));
            button.Width = text.Length > 12 ? 116 : 86;
            button.Tag = value;
            button.Click += (s, e) => onClick(value);
            return button;
        }

        private static Button MakeButton(string text, Color backColor, Color foreColor)
        {
            Button button = new Button
            {
                Text = text,
                Height = 34,
                Margin = new Padding(5, 4, 5, 4),
                FlatStyle = FlatStyle.Flat,
                BackColor = backColor,
                ForeColor = foreColor,
                Font = new Font("Segoe UI", 8, FontStyle.Bold)
            };
            button.FlatAppearance.BorderColor = Color.FromArgb(205, 220, 242);
            button.FlatAppearance.MouseOverBackColor = Color.FromArgb(231, 241, 255);
            return button;
        }

        private static Label MakeLabel(string text, int size, FontStyle style, Color color)
        {
            return new Label
            {
                Text = text,
                Dock = DockStyle.Fill,
                AutoSize = false,
                Font = new Font("Segoe UI", size, style),
                ForeColor = color
            };
        }
    }
}
