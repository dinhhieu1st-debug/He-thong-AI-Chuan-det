using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Server
{
    public sealed class DashboardView : UserControl
    {
        private readonly Label lblTotal;
        private readonly Label lblWarning;
        private readonly Label lblCritical;
        private readonly Label lblOffline;
        private readonly FlowLayoutPanel alertList;
        private readonly FlowLayoutPanel roomSummary;
        private Label lblConnection = null!;

        public DashboardView()
        {
            Dock = DockStyle.Fill;
            BackColor = Color.FromArgb(244, 248, 253);

            TableLayoutPanel root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 4,
                ColumnCount = 1,
                Padding = new Padding(22, 16, 16, 16)
            };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 88));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 118));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 52));
            Controls.Add(root);

            root.Controls.Add(CreateHeader(), 0, 0);
            TableLayoutPanel statRow = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 1 };
            for (int i = 0; i < 4; i++)
            {
                statRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
            }

            lblTotal = AddStat(statRow, 0, "▭", "GIƯỜNG", Color.FromArgb(0, 99, 255));
            lblWarning = AddStat(statRow, 1, "⚠", "CẢNH BÁO", Color.FromArgb(245, 132, 15));
            lblCritical = AddStat(statRow, 2, "⚕", "NGUY CẤP", Color.FromArgb(235, 54, 70));
            lblOffline = AddStat(statRow, 3, "⌁", "NGOẠI TUYẾN", Color.FromArgb(0, 173, 196));
            root.Controls.Add(statRow, 0, 1);

            TableLayoutPanel panels = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
            panels.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            panels.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            alertList = CreateInfoPanel(panels, 0, "Cảnh báo mới nhất");
            roomSummary = CreateInfoPanel(panels, 1, "Tóm tắt theo phòng");
            root.Controls.Add(panels, 0, 2);
        }

        public void UpdateBeds(IEnumerable<BedData> beds)
        {
            List<BedData> data = beds.ToList();
            SuspendLayout();
            lblTotal.Text = data.Count.ToString();
            lblWarning.Text = data.Count(x => x.TrangThai == "CẢNH BÁO").ToString();
            lblCritical.Text = data.Count(x => x.TrangThai == "NGUY CẤP").ToString();
            lblOffline.Text = data.Count(x => x.TrangThai == "NGOẠI TUYẾN").ToString();

            alertList.Controls.Clear();
            foreach (BedData bed in data.Where(x => x.TrangThai == "NGUY CẤP" || x.TrangThai == "CẢNH BÁO").Take(3))
            {
                alertList.Controls.Add(MakeAlertRow(bed));
            }

            if (alertList.Controls.Count == 0)
            {
                alertList.Controls.Add(MakeEmpty("Chưa có cảnh báo mới"));
            }

            roomSummary.Controls.Clear();
            foreach (IGrouping<string, BedData> group in data.GroupBy(x => x.Phong).OrderBy(x => x.Key))
            {
                Label row = MakeLabel(group.Key + ": " + group.Count() + " giường", 10, FontStyle.Bold, Color.FromArgb(18, 43, 73));
                row.Height = 30;
                row.Width = Math.Max(360, roomSummary.ClientSize.Width - 28);
                row.Dock = DockStyle.None;
                row.TextAlign = ContentAlignment.MiddleLeft;
                roomSummary.Controls.Add(row);
            }

            if (roomSummary.Controls.Count == 0)
            {
                roomSummary.Controls.Add(MakeEmpty("Chưa có dữ liệu phòng"));
            }

            ResumeLayout(true);
        }

        public void SetConnectionStatus(string text, bool ok)
        {
            lblConnection.Text = ok ? "● " + text : "● " + text;
            lblConnection.ForeColor = ok ? Color.FromArgb(0, 150, 84) : Color.FromArgb(235, 54, 70);
        }

        private Control CreateHeader()
        {
            TableLayoutPanel header = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 1,
                BackColor = Color.White,
                Padding = new Padding(18, 10, 18, 10)
            };
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 250));

            TableLayoutPanel titleBlock = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2, ColumnCount = 1 };
            titleBlock.RowStyles.Add(new RowStyle(SizeType.Percent, 58));
            titleBlock.RowStyles.Add(new RowStyle(SizeType.Percent, 42));
            Label title = MakeLabel("BẢNG THEO DÕI CHỈ SỐ GIƯỜNG BỆNH", 17, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            Label subtitle = MakeLabel("Giám sát SpO₂, nhịp tim, nhiệt độ và tốc độ nhỏ giọt", 9, FontStyle.Regular, Color.FromArgb(95, 110, 130));
            title.TextAlign = ContentAlignment.BottomLeft;
            subtitle.TextAlign = ContentAlignment.TopLeft;
            titleBlock.Controls.Add(title, 0, 0);
            titleBlock.Controls.Add(subtitle, 0, 1);
            header.Controls.Add(titleBlock, 0, 0);

            Panel status = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(245, 251, 248),
                BorderStyle = BorderStyle.FixedSingle,
                Padding = new Padding(12, 8, 12, 8),
                Margin = new Padding(8)
            };
            lblConnection = MakeLabel("● Server đang chạy", 9, FontStyle.Bold, Color.FromArgb(0, 150, 84));
            lblConnection.TextAlign = ContentAlignment.MiddleCenter;
            status.Controls.Add(lblConnection);
            header.Controls.Add(status, 1, 0);
            return header;
        }

        private static Label AddStat(TableLayoutPanel parent, int column, string icon, string title, Color color)
        {
            Panel card = new Panel
            {
                Dock = DockStyle.Fill,
                Margin = new Padding(0, 14, 14, 12),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };
            TableLayoutPanel layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, Padding = new Padding(14, 8, 12, 8) };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 58));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            Label iconLabel = MakeLabel(icon, 22, FontStyle.Bold, color);
            iconLabel.TextAlign = ContentAlignment.MiddleCenter;
            layout.Controls.Add(iconLabel, 0, 0);

            TableLayoutPanel text = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2, ColumnCount = 1 };
            text.RowStyles.Add(new RowStyle(SizeType.Percent, 58));
            text.RowStyles.Add(new RowStyle(SizeType.Percent, 42));
            Label number = MakeLabel("0", 20, FontStyle.Bold, color);
            Label caption = MakeLabel(title, 8, FontStyle.Bold, Color.FromArgb(95, 110, 130));
            number.TextAlign = ContentAlignment.BottomLeft;
            caption.TextAlign = ContentAlignment.TopLeft;
            text.Controls.Add(number, 0, 0);
            text.Controls.Add(caption, 0, 1);
            layout.Controls.Add(text, 1, 0);
            card.Controls.Add(layout);
            parent.Controls.Add(card, column, 0);
            return number;
        }

        private static FlowLayoutPanel CreateInfoPanel(TableLayoutPanel parent, int column, string title)
        {
            Panel card = new Panel
            {
                Dock = DockStyle.Fill,
                Margin = new Padding(column == 0 ? 0 : 8, 4, column == 0 ? 8 : 0, 8),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Padding = new Padding(16)
            };
            TableLayoutPanel layout = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2, ColumnCount = 1 };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            Label titleLabel = MakeLabel(title, 13, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            titleLabel.TextAlign = ContentAlignment.MiddleLeft;
            FlowLayoutPanel list = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true };
            layout.Controls.Add(titleLabel, 0, 0);
            layout.Controls.Add(list, 0, 1);
            card.Controls.Add(layout);
            parent.Controls.Add(card, column, 0);
            return list;
        }

        private static Control MakeAlertRow(BedData bed)
        {
            Color color = bed.TrangThai == "NGUY CẤP" ? Color.FromArgb(235, 54, 70) : Color.FromArgb(245, 132, 15);
            Label row = MakeLabel(bed.TrangThai + "  •  " + bed.MaGiuong + " - " + BuildMessage(bed), 9, FontStyle.Bold, color);
            row.Height = 34;
            row.Width = 430;
            row.Dock = DockStyle.None;
            row.TextAlign = ContentAlignment.MiddleLeft;
            return row;
        }

        private static Control MakeEmpty(string text)
        {
            Label empty = MakeLabel(text, 10, FontStyle.Regular, Color.FromArgb(95, 110, 130));
            empty.Height = 34;
            empty.Width = 360;
            empty.Dock = DockStyle.None;
            empty.TextAlign = ContentAlignment.MiddleLeft;
            return empty;
        }

        private static string BuildMessage(BedData bed)
        {
            if (bed.Spo2 < 95)
            {
                return "SpO₂ thấp: " + bed.Spo2 + "%";
            }

            if (bed.NhietDo >= 37.5)
            {
                return "Nhiệt độ cao: " + bed.NhietDo.ToString("0.0") + "°C";
            }

            if (bed.NhipTim < 60 || bed.NhipTim > 110)
            {
                return "Nhịp tim bất thường: " + bed.NhipTim;
            }

            return "Cần kiểm tra";
        }

        private static Label MakeLabel(string text, int size, FontStyle style, Color color)
        {
            return new Label
            {
                Text = text,
                Dock = DockStyle.Fill,
                AutoSize = false,
                Font = new Font("Segoe UI", size, style),
                ForeColor = color
            };
        }
    }
}
