using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Server
{
    public sealed class DeviceManagementView : UserControl
    {
        private TextBox txtSearch = null!;
        private FlowLayoutPanel deviceGrid = null!;
        private FlowLayoutPanel scanList = null!;
        private Label lblName = null!;
        private Label lblStatus = null!;
        private Label lblDeviceId = null!;
        private Label lblType = null!;
        private Label lblAssignedBed = null!;
        private Label lblRoom = null!;
        private Label lblBle = null!;
        private Label lblZigbee = null!;
        private Label lblEui64 = null!;
        private Label lblBattery = null!;
        private Label lblUpdated = null!;
        private readonly List<DeviceInfo> devices = new List<DeviceInfo>();

        private string selectedType = "Tất cả";
        private string selectedStatus = "Tất cả";

        public DeviceManagementView()
        {
            Dock = DockStyle.Fill;
            BackColor = Color.FromArgb(244, 248, 253);

            TableLayoutPanel root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 3,
                ColumnCount = 1,
                Padding = new Padding(22, 16, 16, 16)
            };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 72));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 92));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            Controls.Add(root);

            root.Controls.Add(CreateHeader(), 0, 0);
            root.Controls.Add(CreateFilters(), 0, 1);
            root.Controls.Add(CreateContent(), 0, 2);

            SeedDevices();
            RenderDevices();
            Resize += (s, e) => ResizeCards();
        }

        public void RefreshView()
        {
            if (devices.Count == 0)
            {
                SeedDevices();
            }

            SuspendLayout();
            RenderDevices();
            ResumeLayout(true);
            Invalidate(true);
        }

        private Control CreateHeader()
        {
            TableLayoutPanel header = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 1
            };
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 278));

            TableLayoutPanel titleBlock = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 2,
                ColumnCount = 1
            };
            titleBlock.RowStyles.Add(new RowStyle(SizeType.Percent, 58));
            titleBlock.RowStyles.Add(new RowStyle(SizeType.Percent, 42));

            Label title = MakeLabel("QUẢN LÝ THIẾT BỊ", 20, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            title.TextAlign = ContentAlignment.BottomLeft;
            Label subtitle = MakeLabel("Theo dõi xG26, gateway Zigbee, BLE và trạng thái kết nối", 9, FontStyle.Regular, Color.FromArgb(95, 110, 130));
            subtitle.TextAlign = ContentAlignment.TopLeft;
            titleBlock.Controls.Add(title, 0, 0);
            titleBlock.Controls.Add(subtitle, 0, 1);
            header.Controls.Add(titleBlock, 0, 0);

            FlowLayoutPanel actions = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.RightToLeft,
                WrapContents = false,
                Padding = new Padding(0, 6, 0, 12)
            };
            Button refresh = MakeButton("⟳  Làm mới", Color.White, Color.FromArgb(18, 62, 112));
            refresh.Width = 120;
            refresh.Click += (s, e) => RenderDevices();
            Button add = MakeButton("＋  Thêm thiết bị", Color.FromArgb(0, 99, 255), Color.White);
            add.Width = 142;
            actions.Controls.Add(refresh);
            actions.Controls.Add(add);
            header.Controls.Add(actions, 1, 0);
            return header;
        }

        private Control CreateFilters()
        {
            TableLayoutPanel filters = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 2,
                ColumnCount = 1
            };
            filters.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
            filters.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));

            txtSearch = new TextBox
            {
                Width = 380,
                Height = 32,
                Font = new Font("Segoe UI", 9),
                PlaceholderText = "Tìm theo mã thiết bị, giường, phòng..."
            };
            txtSearch.TextChanged += (s, e) => RenderDevices();
            FlowLayoutPanel searchRow = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false };
            searchRow.Controls.Add(txtSearch);
            filters.Controls.Add(searchRow, 0, 0);

            FlowLayoutPanel chips = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false
            };
            chips.Controls.Add(MakeFilterButton("▦  Tất cả", "Tất cả", true, value => selectedType = value));
            chips.Controls.Add(MakeFilterButton("▯  xG26", "xG26", false, value => selectedType = value));
            chips.Controls.Add(MakeFilterButton("▰  Gateway", "Gateway", false, value => selectedType = value));
            chips.Controls.Add(MakeFilterButton("♢  BLE", "BLE", false, value => selectedType = value));
            chips.Controls.Add(MakeFilterButton("●  Đang hoạt động", "TRỰC TUYẾN", false, value => selectedStatus = value));
            chips.Controls.Add(MakeFilterButton("◷  Chờ duyệt", "CHỜ DUYỆT", false, value => selectedStatus = value));
            chips.Controls.Add(MakeFilterButton("⌁  Ngoại tuyến", "NGOẠI TUYẾN", false, value => selectedStatus = value));
            filters.Controls.Add(chips, 0, 1);
            return filters;
        }

        private Control CreateContent()
        {
            TableLayoutPanel content = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 1
            };
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70));
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));

            deviceGrid = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true,
                WrapContents = true,
                BackColor = Color.FromArgb(244, 248, 253),
                Padding = new Padding(0, 4, 6, 6)
            };
            deviceGrid.Resize += (s, e) => ResizeCards();
            content.Controls.Add(deviceGrid, 0, 0);
            content.Controls.Add(CreateInfoPanel(), 1, 0);
            return content;
        }

        private Control CreateInfoPanel()
        {
            Panel panel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Padding = new Padding(16),
                Margin = new Padding(10, 4, 0, 8)
            };

            TableLayoutPanel root = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 4, ColumnCount = 1 };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 82));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 210));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            panel.Controls.Add(root);

            Label title = MakeLabel("THÔNG TIN THIẾT BỊ", 9, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            title.TextAlign = ContentAlignment.MiddleLeft;
            root.Controls.Add(title, 0, 0);

            TableLayoutPanel head = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
            head.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 58));
            head.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            Label icon = MakeLabel("▯", 24, FontStyle.Bold, Color.FromArgb(0, 99, 255));
            icon.TextAlign = ContentAlignment.MiddleCenter;
            head.Controls.Add(icon, 0, 0);
            TableLayoutPanel nameBox = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2, ColumnCount = 1 };
            nameBox.RowStyles.Add(new RowStyle(SizeType.Percent, 58));
            nameBox.RowStyles.Add(new RowStyle(SizeType.Percent, 42));
            lblName = MakeLabel("xG26-01", 12, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            lblStatus = MakeLabel("● TRỰC TUYẾN", 8, FontStyle.Bold, Color.FromArgb(0, 150, 84));
            lblName.TextAlign = ContentAlignment.BottomLeft;
            lblStatus.TextAlign = ContentAlignment.TopLeft;
            nameBox.Controls.Add(lblName, 0, 0);
            nameBox.Controls.Add(lblStatus, 0, 1);
            head.Controls.Add(nameBox, 1, 0);
            root.Controls.Add(head, 0, 1);

            TableLayoutPanel details = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 9 };
            details.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 48));
            details.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 52));
            for (int i = 0; i < 9; i++)
            {
                details.RowStyles.Add(new RowStyle(SizeType.Percent, 11.11f));
            }

            lblDeviceId = AddDetail(details, 0, "Mã thiết bị:");
            lblType = AddDetail(details, 1, "Loại:");
            lblAssignedBed = AddDetail(details, 2, "Gắn cho:");
            lblRoom = AddDetail(details, 3, "Phòng:");
            lblBle = AddDetail(details, 4, "BLE:");
            lblZigbee = AddDetail(details, 5, "Zigbee:");
            lblEui64 = AddDetail(details, 6, "EUI64:");
            lblBattery = AddDetail(details, 7, "Pin:");
            lblUpdated = AddDetail(details, 8, "Cập nhật:");
            root.Controls.Add(details, 0, 2);

            Panel zigbeeBox = new Panel { Dock = DockStyle.Fill, BorderStyle = BorderStyle.FixedSingle, Padding = new Padding(10), Margin = new Padding(0, 8, 0, 0) };
            TableLayoutPanel zigbeeLayout = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2, ColumnCount = 1 };
            zigbeeLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));
            zigbeeLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            zigbeeBox.Controls.Add(zigbeeLayout);
            Label zigbeeTitle = MakeLabel("MẠNG ZIGBEE QUÉT ĐƯỢC", 8, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            zigbeeTitle.TextAlign = ContentAlignment.MiddleLeft;
            zigbeeLayout.Controls.Add(zigbeeTitle, 0, 0);
            scanList = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoScroll = true, FlowDirection = FlowDirection.TopDown, WrapContents = false };
            zigbeeLayout.Controls.Add(scanList, 0, 1);
            root.Controls.Add(zigbeeBox, 0, 3);

            return panel;
        }

        private void SeedDevices()
        {
            devices.Clear();
            devices.Add(new DeviceInfo("xG26-01", "xG26", "Giường 01", "Phòng 01", "TRỰC TUYẾN", "Sẵn sàng", "Đã join", "82%", "-44 dBm", "0x64028FFFFE641802", DateTime.Now));
            devices.Add(new DeviceInfo("xG26-02", "xG26", "Giường 02", "Phòng 01", "CHỜ DUYỆT", "Sẵn sàng", "Chưa join", "81%", "-48 dBm", "0x64028FFFFE641803", DateTime.Now));
            devices.Add(new DeviceInfo("GW-01", "Gateway", "Gateway Phòng 01", "Phòng 01", "TRỰC TUYẾN", "Kênh 20", "Permit join: Bật", "4 thiết bị", "-44 dBm", "0x8B93", DateTime.Now));
            devices.Add(new DeviceInfo("xG26-03", "xG26", "Giường 03", "Phòng 02", "TRỰC TUYẾN", "Sẵn sàng", "Đã join", "76%", "-50 dBm", "0x64028FFFFE641804", DateTime.Now));
            devices.Add(new DeviceInfo("GW-02", "Gateway", "Gateway Phòng 02", "Phòng 02", "NGOẠI TUYẾN", "Kênh 15", "Permit join: Tắt", "Lần thấy: 07:45:12", "-67 dBm", "0x5A21", DateTime.Now.AddMinutes(-40)));
            devices.Add(new DeviceInfo("xG26-04", "xG26", "Giường 04", "Phòng 02", "CẢNH BÁO", "Mất kết nối", "Yếu", "19%", "-72 dBm", "0x64028FFFFE641805", DateTime.Now.AddMinutes(-2)));
        }

        private void RenderDevices()
        {
            string keyword = txtSearch.Text.Trim();
            IEnumerable<DeviceInfo> visible = devices.Where(device =>
                (selectedType == "Tất cả" || device.Type == selectedType || selectedType == "BLE") &&
                (selectedStatus == "Tất cả" || device.Status == selectedStatus) &&
                (string.IsNullOrWhiteSpace(keyword)
                    || device.DeviceId.Contains(keyword, StringComparison.OrdinalIgnoreCase)
                    || device.AssignedTo.Contains(keyword, StringComparison.OrdinalIgnoreCase)
                    || device.Room.Contains(keyword, StringComparison.OrdinalIgnoreCase)));

            deviceGrid.Controls.Clear();
            foreach (DeviceInfo device in visible)
            {
                Control card = CreateDeviceCard(device);
                deviceGrid.Controls.Add(card);
            }

            ShowDeviceInfo(visible.FirstOrDefault() ?? devices.First());
            ResizeCards();
        }

        private Control CreateDeviceCard(DeviceInfo device)
        {
            Panel card = new Panel
            {
                Height = 210,
                Width = 310,
                Margin = new Padding(8),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Padding = new Padding(12)
            };

            TableLayoutPanel root = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 3, ColumnCount = 1 };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 56));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 36));
            card.Controls.Add(root);

            TableLayoutPanel head = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 3, RowCount = 1 };
            head.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 56));
            head.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            head.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 78));
            Label icon = MakeLabel(device.Type == "Gateway" ? "▰" : "▯", 24, FontStyle.Bold, Color.FromArgb(0, 99, 255));
            icon.BackColor = Color.FromArgb(239, 245, 253);
            icon.TextAlign = ContentAlignment.MiddleCenter;
            head.Controls.Add(icon, 0, 0);

            TableLayoutPanel nameBox = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2, ColumnCount = 1 };
            nameBox.RowStyles.Add(new RowStyle(SizeType.Percent, 58));
            nameBox.RowStyles.Add(new RowStyle(SizeType.Percent, 42));
            Label name = MakeLabel(device.DeviceId, 11, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            Label room = MakeLabel(device.AssignedTo + " - " + device.Room, 8, FontStyle.Regular, Color.FromArgb(95, 110, 130));
            name.TextAlign = ContentAlignment.BottomLeft;
            room.TextAlign = ContentAlignment.TopLeft;
            nameBox.Controls.Add(name, 0, 0);
            nameBox.Controls.Add(room, 0, 1);
            head.Controls.Add(nameBox, 1, 0);

            Label status = MakeLabel(device.Status, 7, FontStyle.Bold, GetStatusColor(device.Status));
            status.TextAlign = ContentAlignment.MiddleCenter;
            status.BackColor = Lighten(GetStatusColor(device.Status));
            status.Margin = new Padding(0, 11, 0, 11);
            head.Controls.Add(status, 2, 0);
            root.Controls.Add(head, 0, 0);

            TableLayoutPanel info = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 4 };
            info.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45));
            info.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 55));
            for (int i = 0; i < 4; i++)
            {
                info.RowStyles.Add(new RowStyle(SizeType.Percent, 25));
            }
            AddInfoRow(info, 0, "♢  BLE:", device.Ble);
            AddInfoRow(info, 1, "⌁  Zigbee:", device.Zigbee);
            AddInfoRow(info, 2, "▣  Pin/RSSI:", device.Type == "Gateway" ? device.Battery : device.Battery + "  •  " + device.Rssi);
            AddInfoRow(info, 3, "◷  Cập nhật:", device.UpdatedAt.ToString("HH:mm:ss"));
            root.Controls.Add(info, 0, 1);

            Button detail = MakeButton("Chi tiết  ›", Color.White, Color.FromArgb(0, 99, 255));
            detail.Dock = DockStyle.Right;
            detail.Width = 84;
            detail.Click += (s, e) => ShowDeviceInfo(device);
            root.Controls.Add(detail, 0, 2);

            card.Click += (s, e) => ShowDeviceInfo(device);
            return card;
        }

        private void ShowDeviceInfo(DeviceInfo device)
        {
            lblName.Text = device.DeviceId;
            lblStatus.Text = "● " + device.Status;
            lblStatus.ForeColor = GetStatusColor(device.Status);
            lblDeviceId.Text = device.DeviceId;
            lblType.Text = device.Type;
            lblAssignedBed.Text = device.AssignedTo;
            lblRoom.Text = device.Room;
            lblBle.Text = device.Ble;
            lblZigbee.Text = device.Zigbee;
            lblEui64.Text = device.Eui64;
            lblBattery.Text = device.Battery;
            lblUpdated.Text = device.UpdatedAt.ToString("HH:mm:ss  dd/MM/yyyy");

            scanList.Controls.Clear();
            scanList.Controls.Add(MakeScanRow("Gateway P01", "CH20", "0x8B93", "-44 dBm", "Có", Color.FromArgb(0, 150, 84)));
            scanList.Controls.Add(MakeScanRow("Gateway P02", "CH15", "0x5A21", "-67 dBm", "Không", Color.FromArgb(235, 54, 70)));
            scanList.Controls.Add(MakeScanRow("Mạng dự phòng", "CH11", "0x1C44", "-72 dBm", "Có", Color.FromArgb(0, 150, 84)));
        }

        private void ResizeCards()
        {
            if (deviceGrid.ClientSize.Width <= 0)
            {
                return;
            }

            int available = deviceGrid.ClientSize.Width - deviceGrid.Padding.Left - deviceGrid.Padding.Right - SystemInformation.VerticalScrollBarWidth - 10;
            int columns = available >= 900 ? 3 : available >= 600 ? 2 : 1;
            int width = Math.Max(280, (available / columns) - 18);
            foreach (Control control in deviceGrid.Controls)
            {
                control.Width = width;
            }
        }

        private static Label AddDetail(TableLayoutPanel parent, int row, string title)
        {
            Label left = MakeLabel(title, 8, FontStyle.Regular, Color.FromArgb(95, 110, 130));
            Label right = MakeLabel("--", 8, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            left.TextAlign = ContentAlignment.MiddleLeft;
            right.TextAlign = ContentAlignment.MiddleRight;
            parent.Controls.Add(left, 0, row);
            parent.Controls.Add(right, 1, row);
            return right;
        }

        private static void AddInfoRow(TableLayoutPanel parent, int row, string title, string value)
        {
            Label left = MakeLabel(title, 8, FontStyle.Regular, Color.FromArgb(75, 90, 112));
            Label right = MakeLabel(value, 8, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            left.TextAlign = ContentAlignment.MiddleLeft;
            right.TextAlign = ContentAlignment.MiddleRight;
            parent.Controls.Add(left, 0, row);
            parent.Controls.Add(right, 1, row);
        }

        private static Control MakeScanRow(string name, string channel, string pan, string rssi, string join, Color joinColor)
        {
            Label row = MakeLabel($"{name,-14}  {channel}  {pan}  {rssi}  {join}", 7, FontStyle.Bold, joinColor);
            row.Height = 26;
            row.Width = 310;
            row.TextAlign = ContentAlignment.MiddleLeft;
            return row;
        }

        private static Button MakeFilterButton(string text, string value, bool active, Action<string> setValue)
        {
            Button button = MakeButton(text, active ? Color.FromArgb(231, 241, 255) : Color.White, Color.FromArgb(18, 62, 112));
            button.Width = text.Length > 13 ? 124 : 86;
            button.Click += (s, e) =>
            {
                setValue(value);
                Control? parent = button.Parent;
                while (parent != null && parent is not DeviceManagementView)
                {
                    parent = parent.Parent;
                }

                if (parent is DeviceManagementView view)
                {
                    view.RenderDevices();
                }
            };
            return button;
        }

        private static Button MakeButton(string text, Color backColor, Color foreColor)
        {
            Button button = new Button
            {
                Text = text,
                Height = 34,
                Margin = new Padding(5, 4, 5, 4),
                FlatStyle = FlatStyle.Flat,
                BackColor = backColor,
                ForeColor = foreColor,
                Font = new Font("Segoe UI", 8, FontStyle.Bold)
            };
            button.FlatAppearance.BorderColor = Color.FromArgb(205, 220, 242);
            return button;
        }

        private static Label MakeLabel(string text, int size, FontStyle style, Color color)
        {
            return new Label
            {
                Text = text,
                Dock = DockStyle.Fill,
                AutoSize = false,
                Font = new Font("Segoe UI", size, style),
                ForeColor = color
            };
        }

        private static Color GetStatusColor(string status)
        {
            if (status == "TRỰC TUYẾN")
            {
                return Color.FromArgb(0, 150, 84);
            }

            if (status == "CHỜ DUYỆT")
            {
                return Color.FromArgb(245, 132, 15);
            }

            if (status == "CẢNH BÁO")
            {
                return Color.FromArgb(235, 54, 70);
            }

            return Color.FromArgb(105, 118, 135);
        }

        private static Color Lighten(Color color)
        {
            return Color.FromArgb(
                245,
                Math.Min(255, color.R + 235) / 2,
                Math.Min(255, color.G + 245) / 2,
                Math.Min(255, color.B + 255) / 2);
        }

        private sealed record DeviceInfo(
            string DeviceId,
            string Type,
            string AssignedTo,
            string Room,
            string Status,
            string Ble,
            string Zigbee,
            string Battery,
            string Rssi,
            string Eui64,
            DateTime UpdatedAt);
    }
}
