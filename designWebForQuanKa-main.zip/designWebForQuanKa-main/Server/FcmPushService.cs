using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace Server
{
    public sealed class FcmPushService
    {
        private const string Scope = "https://www.googleapis.com/auth/firebase.messaging";

        private readonly object tokenLock = new object();
        private readonly HashSet<string> deviceTokens = new HashSet<string>(StringComparer.Ordinal);
        private readonly string tokenStorePath;
        private readonly string serviceAccountPath;
        private readonly string projectId;
        private readonly Action<string> reportStatus;
        private readonly HttpClient httpClient = new HttpClient();

        public FcmPushService(Action<string> reportStatus)
        {
            this.reportStatus = reportStatus;
            tokenStorePath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "FPT-HIS",
                "fcm_tokens.txt");
            serviceAccountPath = ResolveServiceAccountPath();
            projectId = TryReadProjectId(serviceAccountPath);
            LoadTokens();
        }

        public int TokenCount
        {
            get
            {
                lock (tokenLock)
                {
                    return deviceTokens.Count;
                }
            }
        }

        public void RegisterToken(string token)
        {
            if (string.IsNullOrWhiteSpace(token))
            {
                return;
            }

            lock (tokenLock)
            {
                deviceTokens.Add(token.Trim());
                SaveTokensLocked();
            }
        }

        public async Task SendAlertAsync(AlertData alert)
        {
            if (string.IsNullOrWhiteSpace(projectId) || !File.Exists(serviceAccountPath))
            {
                reportStatus("Chưa cấu hình Firebase service account, không gửi được push cảnh báo.");
                return;
            }

            List<string> tokens;
            lock (tokenLock)
            {
                tokens = deviceTokens.ToList();
            }

            if (tokens.Count == 0)
            {
                reportStatus("Chưa có app Android đăng ký FCM token.");
                return;
            }

            string accessToken = await CreateAccessTokenAsync();
            string endpoint = $"https://fcm.googleapis.com/v1/projects/{projectId}/messages:send";
            List<string> failedTokens = new List<string>();

            foreach (string token in tokens)
            {
                object payload = new
                {
                    message = new
                    {
                        token,
                        notification = new
                        {
                            title = $"{alert.Level} - {alert.BedId}",
                            body = alert.Message
                        },
                        data = new Dictionary<string, string>
                        {
                            ["type"] = "bed_alert",
                            ["alertId"] = alert.Id,
                            ["bedId"] = alert.BedId,
                            ["room"] = alert.Room,
                            ["level"] = alert.Level,
                            ["message"] = alert.Message,
                            ["createdAt"] = alert.CreatedAt.ToString("yyyy-MM-ddTHH:mm:ss")
                        },
                        android = new
                        {
                            priority = "HIGH",
                            notification = new
                            {
                                channel_id = "bed_alerts",
                                sound = "default"
                            }
                        }
                    }
                };

                using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, endpoint);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                request.Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");

                try
                {
                    using HttpResponseMessage response = await httpClient.SendAsync(request);
                    if (!response.IsSuccessStatusCode)
                    {
                        string error = await response.Content.ReadAsStringAsync();
                        reportStatus($"FCM gửi lỗi HTTP {(int)response.StatusCode}: {Trim(error, 160)}");
                        if ((int)response.StatusCode == 404 || (int)response.StatusCode == 400)
                        {
                            failedTokens.Add(token);
                        }
                    }
                }
                catch (Exception ex)
                {
                    reportStatus("Không gửi được FCM: " + ex.Message);
                }
            }

            if (failedTokens.Count > 0)
            {
                lock (tokenLock)
                {
                    foreach (string failedToken in failedTokens)
                    {
                        deviceTokens.Remove(failedToken);
                    }

                    SaveTokensLocked();
                }
            }
        }

        private async Task<string> CreateAccessTokenAsync()
        {
            using JsonDocument document = JsonDocument.Parse(File.ReadAllText(serviceAccountPath));
            JsonElement root = document.RootElement;
            string clientEmail = root.GetProperty("client_email").GetString() ?? string.Empty;
            string privateKey = root.GetProperty("private_key").GetString() ?? string.Empty;
            long now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();

            object header = new { alg = "RS256", typ = "JWT" };
            object payload = new
            {
                iss = clientEmail,
                scope = Scope,
                aud = "https://oauth2.googleapis.com/token",
                iat = now,
                exp = now + 3600
            };

            string unsignedJwt = Base64Url(JsonSerializer.SerializeToUtf8Bytes(header))
                + "."
                + Base64Url(JsonSerializer.SerializeToUtf8Bytes(payload));

            using RSA rsa = RSA.Create();
            rsa.ImportFromPem(privateKey);
            byte[] signature = rsa.SignData(Encoding.UTF8.GetBytes(unsignedJwt), HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            string assertion = unsignedJwt + "." + Base64Url(signature);

            using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "https://oauth2.googleapis.com/token");
            request.Content = new FormUrlEncodedContent(new Dictionary<string, string>
            {
                ["grant_type"] = "urn:ietf:params:oauth:grant-type:jwt-bearer",
                ["assertion"] = assertion
            });

            using HttpResponseMessage response = await httpClient.SendAsync(request);
            string json = await response.Content.ReadAsStringAsync();
            if (!response.IsSuccessStatusCode)
            {
                throw new InvalidOperationException("OAuth token lỗi HTTP " + (int)response.StatusCode + ": " + Trim(json, 160));
            }

            using JsonDocument tokenDocument = JsonDocument.Parse(json);
            return tokenDocument.RootElement.GetProperty("access_token").GetString() ?? string.Empty;
        }

        private static string Base64Url(byte[] data)
        {
            return Convert.ToBase64String(data)
                .TrimEnd('=')
                .Replace('+', '-')
                .Replace('/', '_');
        }

        private void LoadTokens()
        {
            if (!File.Exists(tokenStorePath))
            {
                return;
            }

            lock (tokenLock)
            {
                foreach (string line in File.ReadAllLines(tokenStorePath))
                {
                    if (!string.IsNullOrWhiteSpace(line))
                    {
                        deviceTokens.Add(line.Trim());
                    }
                }
            }
        }

        private void SaveTokensLocked()
        {
            Directory.CreateDirectory(Path.GetDirectoryName(tokenStorePath)!);
            File.WriteAllLines(tokenStorePath, deviceTokens.OrderBy(x => x));
        }

        private static string ResolveServiceAccountPath()
        {
            string? configured = Environment.GetEnvironmentVariable("FPT_FIREBASE_SERVICE_ACCOUNT");
            if (!string.IsNullOrWhiteSpace(configured))
            {
                return configured;
            }

            return Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                "Downloads",
                "FPT-Health.json");
        }

        private static string TryReadProjectId(string path)
        {
            if (!File.Exists(path))
            {
                return string.Empty;
            }

            using JsonDocument document = JsonDocument.Parse(File.ReadAllText(path));
            return document.RootElement.TryGetProperty("project_id", out JsonElement projectId)
                ? projectId.GetString() ?? string.Empty
                : string.Empty;
        }

        private static string Trim(string value, int maxLength)
        {
            return value.Length <= maxLength ? value : value.Substring(0, maxLength) + "...";
        }
    }
}
