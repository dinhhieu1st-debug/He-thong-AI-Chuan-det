using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;
using Microsoft.Web.WebView2.WinForms;

namespace Server
{
    public partial class Form1 : Form
    {
        private const int CongNhanDuLieu = 5000;

        private FlowLayoutPanel khungTheDuLieu = null!;
        private FlowLayoutPanel khungDanhSachCanhBao = null!;
        private Label lblTrangThaiKetNoi = null!;
        private Panel khungNoiDungChinh = null!;
        private DashboardView manHinhDashboard = null!;
        private BedManagementView manHinhGiuong = null!;
        private AlertManagementView manHinhCanhBao = null!;
        private DeviceManagementView manHinhThietBi = null!;
        private SystemLogView manHinhNhatKy = null!;
        private Button nutDashboard = null!;
        private Button nutGiuongBenh = null!;
        private Button nutCanhBao = null!;
        private Button nutThietBi = null!;
        private Button nutNhatKy = null!;
        private WebView2 webView = null!;
        private readonly Dictionary<string, BedCardView> danhSachGiuong = new Dictionary<string, BedCardView>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, BedData> duLieuGiuongHienTai = new Dictionary<string, BedData>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, Label> nhanThongKe = new Dictionary<string, Label>(StringComparer.OrdinalIgnoreCase);
        private readonly List<Panel> danhSachThe = new List<Panel>();
        private readonly BedDataReceiver boNhanDuLieu;
        private string boLocHienTai = "Tất cả";
        private readonly System.Windows.Forms.Timer timerKiemTraKetNoi = new System.Windows.Forms.Timer();
        private readonly object apiDataLock = new object();
        private readonly Dictionary<string, BedData> apiBeds = new Dictionary<string, BedData>(StringComparer.OrdinalIgnoreCase);
        private readonly List<AlertData> apiAlerts = new List<AlertData>();
        private int alertCounter;
        private ApiServer? apiServer;
        private Process? cloudflaredProcess;
        private readonly MySqlHistoryRepository historyRepository = new MySqlHistoryRepository();
        private readonly FcmPushService fcmPushService;
        private readonly Dictionary<string, DateTime> lanLuuSinhTonGanNhat = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);
        private int chuKyLuuSinhTonGiay = 10;

        public Form1()
        {
            InitializeComponent();
            fcmPushService = new FcmPushService(HienThiTrangThaiApi);

            boNhanDuLieu = new BedDataReceiver(CongNhanDuLieu);
            boNhanDuLieu.DataReceived += XuLyDuLieuMoi;
            boNhanDuLieu.ErrorOccurred += HienThiLoiNhanDuLieu;

            TaoGiaoDien();
            KhoiDongNhanDuLieu();
            KhoiDongApiServer();
            KhoiDongCloudflared();
            KhoiDongKiemTraKetNoi();
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            timerKiemTraKetNoi.Stop();
            timerKiemTraKetNoi.Dispose();

            boNhanDuLieu.Dispose();
            apiServer?.Dispose();
            DungCloudflared();

            base.OnFormClosed(e);
        }

        private async void TaoGiaoDien()
        {
            Controls.Clear();
            nhanThongKe.Clear();
            danhSachGiuong.Clear();
            danhSachThe.Clear();
            duLieuGiuongHienTai.Clear();

            Text = "HIS Server Console";
            MinimumSize = new Size(1120, 680);
            Size = new Size(1280, 720);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(242, 246, 251);
            AutoScaleMode = AutoScaleMode.Dpi;
            Font = new Font("Segoe UI", 9F, FontStyle.Regular);

            // Initialize old views in memory to prevent backend NullReferenceException
            manHinhDashboard = new DashboardView();
            manHinhGiuong = new BedManagementView();
            manHinhGiuong.SaveIntervalRequested += (s, e) => HienThiCauHinhChuKyLuuSql();
            manHinhCanhBao = new AlertManagementView();
            manHinhThietBi = new DeviceManagementView();
            manHinhNhatKy = new SystemLogView();
            lblTrangThaiKetNoi = new Label();

            // Initialize WebView2
            webView = new WebView2
            {
                Dock = DockStyle.Fill
            };
            Controls.Add(webView);

            string htmlPath = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\..\Thiết kế lại giao diện responsive\HIS Server Console.dc.html"));
            
            await webView.EnsureCoreWebView2Async();
            webView.CoreWebView2.Navigate("file:///" + htmlPath.Replace("\\", "/"));

            TaoBonGiuongBenh();
            CapNhatThongKe();
        }

        private Control TaoThanhDieuHuong()
        {
            Panel sidebar = new Panel();
            sidebar.Dock = DockStyle.Fill;
            sidebar.BackColor = Color.FromArgb(4, 41, 81);
            sidebar.Padding = new Padding(10, 12, 10, 12);

            Label tenApp = new Label();
            tenApp.Text = "▣  HIS Server\nConsole";
            tenApp.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            tenApp.ForeColor = Color.White;
            tenApp.Location = new Point(12, 12);
            tenApp.Size = new Size(118, 42);
            sidebar.Controls.Add(tenApp);

            int y = 62;
            nutDashboard = TaoNutDieuHuong("▦  Dashboard", y, () => ChuyenTab("Dashboard"));
            sidebar.Controls.Add(nutDashboard);
            y += 48;

            nutGiuongBenh = TaoNutDieuHuong("▭  Giường bệnh", y, () => ChuyenTab("Giường bệnh"));
            sidebar.Controls.Add(nutGiuongBenh);
            y += 48;

            nutCanhBao = TaoNutDieuHuong("⚠  Cảnh báo", y, () => ChuyenTab("Cảnh báo"));
            sidebar.Controls.Add(nutCanhBao);
            y += 48;
            sidebar.Controls.Add(TaoNutDieuHuong("○  Bệnh nhân", y, null));
            y += 48;

            nutThietBi = TaoNutDieuHuong("▣  Thiết bị", y, () => ChuyenTab("Thiết bị"));
            sidebar.Controls.Add(nutThietBi);
            y += 48;

            sidebar.Controls.Add(TaoNutDieuHuong("▥  Báo cáo", y, null));
            y += 48;
            sidebar.Controls.Add(TaoNutDieuHuong("⚙  Cài đặt", y, null));
            y += 48;
            nutNhatKy = TaoNutDieuHuong("▤  Nhật ký", y, () => ChuyenTab("Nhật ký"));
            sidebar.Controls.Add(nutNhatKy);

            Panel admin = new Panel();
            admin.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
            admin.Location = new Point(10, 590);
            admin.Size = new Size(124, 56);
            admin.BackColor = Color.FromArgb(13, 66, 120);
            sidebar.Controls.Add(admin);

            Label avatar = new Label();
            avatar.Text = "SA";
            avatar.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            avatar.ForeColor = Color.White;
            avatar.BackColor = Color.FromArgb(82, 132, 190);
            avatar.TextAlign = ContentAlignment.MiddleCenter;
            avatar.Location = new Point(8, 13);
            avatar.Size = new Size(30, 30);
            admin.Controls.Add(avatar);

            Label user = new Label();
            user.Text = "admin\nQuản trị viên";
            user.Font = new Font("Segoe UI", 7, FontStyle.Regular);
            user.ForeColor = Color.White;
            user.Location = new Point(45, 11);
            user.Size = new Size(70, 34);
            admin.Controls.Add(user);

            return sidebar;
        }

        private Button TaoNutDieuHuong(string noiDung, int y, Action? xuLyClick)
        {
            Button nut = new Button();
            nut.Text = noiDung;
            nut.FlatStyle = FlatStyle.Flat;
            nut.FlatAppearance.BorderSize = 0;
            nut.ForeColor = Color.White;
            nut.BackColor = Color.Transparent;
            nut.TextAlign = ContentAlignment.MiddleLeft;
            nut.Font = new Font("Segoe UI", 9, FontStyle.Regular);
            nut.Location = new Point(8, y);
            nut.Size = new Size(124, 42);
            nut.Padding = new Padding(10, 0, 0, 0);
            nut.Cursor = xuLyClick == null ? Cursors.Default : Cursors.Hand;

            if (xuLyClick != null)
            {
                nut.Click += (s, e) => xuLyClick();
            }

            return nut;
        }

        private void ChuyenTab(string tab)
        {
            bool laDashboard = tab == "Dashboard";
            bool laGiuongBenh = tab == "Giường bệnh";
            bool laCanhBao = tab == "Cảnh báo";
            bool laThietBi = tab == "Thiết bị";
            bool laNhatKy = tab == "Nhật ký";

            Control? manHinhDangChon = null;
            khungNoiDungChinh.SuspendLayout();
            manHinhDashboard.Visible = false;
            manHinhGiuong.Visible = false;
            manHinhCanhBao.Visible = false;
            manHinhThietBi.Visible = false;
            manHinhNhatKy.Visible = false;

            if (laDashboard)
            {
                manHinhDashboard.UpdateBeds(duLieuGiuongHienTai.Values);
                manHinhDangChon = manHinhDashboard;
            }
            else if (laGiuongBenh)
            {
                manHinhGiuong.RefreshView();
                manHinhDangChon = manHinhGiuong;
            }
            else if (laCanhBao)
            {
                manHinhDangChon = manHinhCanhBao;
                _ = manHinhCanhBao.RefreshFromDatabaseAsync();
            }
            else if (laThietBi)
            {
                manHinhDangChon = manHinhThietBi;
                manHinhThietBi.RefreshView();
            }
            else
            {
                manHinhDangChon = manHinhNhatKy;
            }

            if (manHinhDangChon != null)
            {
                khungNoiDungChinh.Controls.SetChildIndex(manHinhDangChon, 0);
                manHinhDangChon.Visible = true;
                manHinhDangChon.BringToFront();
                manHinhDangChon.Invalidate(true);
            }

            khungNoiDungChinh.ResumeLayout(true);
            CapNhatTrangThaiNutDieuHuong(nutDashboard, laDashboard);
            CapNhatTrangThaiNutDieuHuong(nutGiuongBenh, laGiuongBenh);
            CapNhatTrangThaiNutDieuHuong(nutCanhBao, laCanhBao);
            CapNhatTrangThaiNutDieuHuong(nutThietBi, laThietBi);
            CapNhatTrangThaiNutDieuHuong(nutNhatKy, laNhatKy);
        }

        private void CapNhatTrangThaiNutDieuHuong(Button nut, bool dangChon)
        {
            nut.BackColor = dangChon ? Color.FromArgb(39, 125, 235) : Color.Transparent;
            nut.Font = new Font("Segoe UI", 9, dangChon ? FontStyle.Bold : FontStyle.Regular);
        }

        private Control TaoThanhTieuDe()
        {
            TableLayoutPanel header = new TableLayoutPanel();
            header.Dock = DockStyle.Fill;
            header.BackColor = Color.White;
            header.ColumnCount = 2;
            header.RowCount = 1;
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 46));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 54));
            header.Padding = new Padding(28, 12, 18, 10);

            Panel khungTieuDe = new Panel();
            khungTieuDe.Dock = DockStyle.Fill;

            Label tieuDe = new Label();
            tieuDe.Text = "BẢNG THEO DÕI CHỈ SỐ GIƯỜNG BỆNH";
            tieuDe.Font = new Font("Segoe UI", 18, FontStyle.Bold);
            tieuDe.ForeColor = Color.FromArgb(18, 43, 73);
            tieuDe.AutoSize = true;
            tieuDe.Location = new Point(0, 8);
            khungTieuDe.Controls.Add(tieuDe);

            Label moTa = new Label();
            moTa.Text = "Giám sát SpO₂, nhịp tim, nhiệt độ và tốc độ nhỏ giọt";
            moTa.Font = new Font("Segoe UI", 9, FontStyle.Regular);
            moTa.ForeColor = Color.FromArgb(100, 113, 132);
            moTa.AutoSize = true;
            moTa.Location = new Point(2, 44);
            khungTieuDe.Controls.Add(moTa);

            FlowLayoutPanel dongTrangThai = new FlowLayoutPanel();
            dongTrangThai.Location = new Point(0, 70);
            dongTrangThai.Size = new Size(560, 24);
            dongTrangThai.WrapContents = false;
            dongTrangThai.Controls.Add(TaoTrangThaiNho("TCP 5000: Đang chạy"));
            dongTrangThai.Controls.Add(TaoTrangThaiNho("HTTP API 8080: Đang chạy"));
            dongTrangThai.Controls.Add(TaoTrangThaiNho("Cloudflare Tunnel: Đang chạy"));
            khungTieuDe.Controls.Add(dongTrangThai);

            lblTrangThaiKetNoi = new Label();
            lblTrangThaiKetNoi.Text = $"TCP {CongNhanDuLieu}: Đang chạy";
            lblTrangThaiKetNoi.Visible = false;
            khungTieuDe.Controls.Add(lblTrangThaiKetNoi);

            FlowLayoutPanel thongKe = new FlowLayoutPanel();
            thongKe.Dock = DockStyle.Fill;
            thongKe.FlowDirection = FlowDirection.RightToLeft;
            thongKe.WrapContents = false;
            thongKe.Padding = new Padding(0, 8, 0, 0);

            thongKe.Controls.Add(TaoOThongKe("Ngoại tuyến", "0", "NGOẠI TUYẾN", "⌁", Color.FromArgb(105, 118, 135)));
            thongKe.Controls.Add(TaoOThongKe("Nguy cấp", "0", "NGUY CẤP", "⚕", Color.FromArgb(235, 54, 70)));
            thongKe.Controls.Add(TaoOThongKe("Cảnh báo", "0", "CẢNH BÁO", "⚠", Color.FromArgb(245, 132, 15)));
            thongKe.Controls.Add(TaoOThongKe("Giường", "0", "GIƯỜNG", "▭", Color.FromArgb(36, 123, 230)));

            header.Controls.Add(khungTieuDe, 0, 0);
            header.Controls.Add(thongKe, 1, 0);
            return header;
        }

        private Label TaoTrangThaiNho(string text)
        {
            Label lbl = new Label();
            lbl.Text = "● " + text;
            lbl.AutoSize = true;
            lbl.Font = new Font("Segoe UI", 8, FontStyle.Regular);
            lbl.ForeColor = Color.FromArgb(30, 150, 80);
            lbl.Margin = new Padding(0, 0, 22, 0);
            return lbl;
        }

        private Panel TaoOThongKe(string khoa, string so, string ten, string icon, Color mau)
        {
            Panel o = new Panel();
            o.Size = new Size(128, 72);
            o.Margin = new Padding(6);
            o.BackColor = Color.FromArgb(249, 251, 254);
            o.BorderStyle = BorderStyle.FixedSingle;

            Label lblIcon = new Label();
            lblIcon.Text = icon;
            lblIcon.Font = new Font("Segoe UI Symbol", 18, FontStyle.Bold);
            lblIcon.ForeColor = mau;
            lblIcon.TextAlign = ContentAlignment.MiddleCenter;
            lblIcon.Location = new Point(8, 12);
            lblIcon.Size = new Size(34, 42);
            o.Controls.Add(lblIcon);

            Label lblSo = new Label();
            lblSo.Text = so;
            lblSo.Font = new Font("Segoe UI", 17, FontStyle.Bold);
            lblSo.ForeColor = mau;
            lblSo.AutoSize = true;
            lblSo.Location = new Point(50, 11);
            o.Controls.Add(lblSo);
            nhanThongKe[khoa] = lblSo;

            Label lblTen = new Label();
            lblTen.Text = ten;
            lblTen.Font = new Font("Segoe UI", 7, FontStyle.Bold);
            lblTen.ForeColor = Color.FromArgb(90, 100, 116);
            lblTen.AutoSize = true;
            lblTen.Location = new Point(51, 42);
            o.Controls.Add(lblTen);
            return o;
        }

        private Control TaoThanhTimKiemVaLoc()
        {
            TableLayoutPanel thanhLoc = new TableLayoutPanel();
            thanhLoc.Dock = DockStyle.Fill;
            thanhLoc.BackColor = Color.FromArgb(242, 246, 251);
            thanhLoc.ColumnCount = 2;
            thanhLoc.RowCount = 1;
            thanhLoc.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            thanhLoc.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120));
            thanhLoc.Padding = new Padding(22, 12, 18, 9);

            FlowLayoutPanel trai = new FlowLayoutPanel();
            trai.Dock = DockStyle.Fill;
            trai.WrapContents = false;

            TextBox txtTimKiem = new TextBox();
            txtTimKiem.Width = 310;
            txtTimKiem.Height = 34;
            txtTimKiem.Font = new Font("Segoe UI", 9);
            txtTimKiem.PlaceholderText = "Tìm kiếm theo mã giường, phòng...";
            txtTimKiem.Margin = new Padding(0, 0, 16, 0);
            txtTimKiem.TextChanged += (s, e) => ApDungBoLoc(txtTimKiem.Text);
            trai.Controls.Add(txtTimKiem);

            trai.Controls.Add(TaoNutLoc("▦  Tất cả", "Tất cả", txtTimKiem));
            trai.Controls.Add(TaoNutLoc("⚕  Nguy cấp", "Nguy cấp", txtTimKiem));
            trai.Controls.Add(TaoNutLoc("⚠  Cảnh báo", "Cảnh báo", txtTimKiem));
            trai.Controls.Add(TaoNutLoc("✓  Ổn định", "Ổn định", txtTimKiem));
            trai.Controls.Add(TaoNutLoc("⌁  Ngoại tuyến", "Ngoại tuyến", txtTimKiem));

            Button lamMoi = TaoNutHanhDong("⟳  Làm mới");
            lamMoi.Dock = DockStyle.Fill;
            lamMoi.Click += (s, e) =>
            {
                CapNhatThongKe();
                DieuChinhKichThuocThe();
                DieuChinhKichThuocCanhBao();
            };

            thanhLoc.Controls.Add(trai, 0, 0);
            thanhLoc.Controls.Add(lamMoi, 1, 0);
            return thanhLoc;
        }

        private Button TaoNutLoc(string hienThi, string giaTriLoc, TextBox txtTimKiem)
        {
            Button nut = TaoNutHanhDong(hienThi);
            nut.Size = new Size(98, 34);
            nut.Margin = new Padding(5, 0, 5, 0);
            nut.Click += (s, e) =>
            {
                boLocHienTai = giaTriLoc;
                ApDungBoLoc(txtTimKiem.Text);
            };
            return nut;
        }

        private Button TaoNutHanhDong(string noiDung)
        {
            Button nut = new Button();
            nut.Text = noiDung;
            nut.FlatStyle = FlatStyle.Flat;
            nut.BackColor = Color.White;
            nut.ForeColor = Color.FromArgb(18, 62, 112);
            nut.Font = new Font("Segoe UI", 8, FontStyle.Bold);
            nut.FlatAppearance.BorderColor = Color.FromArgb(214, 224, 238);
            nut.FlatAppearance.MouseOverBackColor = Color.FromArgb(235, 244, 255);
            return nut;
        }

        private Control TaoKhuVucNoiDung()
        {
            TableLayoutPanel noiDung = new TableLayoutPanel();
            noiDung.Dock = DockStyle.Fill;
            noiDung.BackColor = Color.FromArgb(242, 246, 251);
            noiDung.ColumnCount = 2;
            noiDung.RowCount = 1;
            noiDung.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 74));
            noiDung.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 26));

            khungTheDuLieu = new FlowLayoutPanel();
            khungTheDuLieu.Dock = DockStyle.Fill;
            khungTheDuLieu.AutoScroll = true;
            khungTheDuLieu.WrapContents = true;
            khungTheDuLieu.Padding = new Padding(22, 18, 10, 18);
            khungTheDuLieu.BackColor = Color.FromArgb(242, 246, 251);

            Panel khungCanhBao = TaoKhungCanhBao();
            khungCanhBao.Margin = new Padding(6, 18, 18, 18);

            noiDung.Controls.Add(khungTheDuLieu, 0, 0);
            noiDung.Controls.Add(khungCanhBao, 1, 0);
            return noiDung;
        }

        private Panel TaoKhungCanhBao()
        {
            Panel khung = new Panel();
            khung.Dock = DockStyle.Fill;
            khung.BackColor = Color.White;
            khung.Padding = new Padding(16, 14, 16, 14);
            khung.BorderStyle = BorderStyle.FixedSingle;

            TableLayoutPanel boCucCanhBao = new TableLayoutPanel();
            boCucCanhBao.Dock = DockStyle.Fill;
            boCucCanhBao.RowCount = 2;
            boCucCanhBao.ColumnCount = 1;
            boCucCanhBao.RowStyles.Add(new RowStyle(SizeType.Absolute, 54));
            boCucCanhBao.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            khung.Controls.Add(boCucCanhBao);

            TableLayoutPanel thanhTren = new TableLayoutPanel();
            thanhTren.Dock = DockStyle.Fill;
            thanhTren.ColumnCount = 2;
            thanhTren.RowCount = 1;
            thanhTren.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            thanhTren.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 112));

            Label tieuDe = new Label();
            tieuDe.Text = "CẢNH BÁO";
            tieuDe.Font = new Font("Segoe UI", 15, FontStyle.Bold);
            tieuDe.ForeColor = Color.FromArgb(18, 43, 73);
            tieuDe.Dock = DockStyle.Fill;
            tieuDe.TextAlign = ContentAlignment.MiddleLeft;

            Button nutXacNhan = TaoNutHanhDong("Xác nhận tất cả");
            nutXacNhan.Dock = DockStyle.Fill;
            nutXacNhan.Margin = new Padding(5, 9, 0, 9);
            nutXacNhan.Click += (s, e) => khungDanhSachCanhBao.Controls.Clear();

            thanhTren.Controls.Add(tieuDe, 0, 0);
            thanhTren.Controls.Add(nutXacNhan, 1, 0);

            khungDanhSachCanhBao = new FlowLayoutPanel();
            khungDanhSachCanhBao.Dock = DockStyle.Fill;
            khungDanhSachCanhBao.AutoScroll = true;
            khungDanhSachCanhBao.FlowDirection = FlowDirection.TopDown;
            khungDanhSachCanhBao.WrapContents = false;
            khungDanhSachCanhBao.Padding = new Padding(0, 4, 0, 0);
            khungDanhSachCanhBao.BackColor = Color.White;

            boCucCanhBao.Controls.Add(thanhTren, 0, 0);
            boCucCanhBao.Controls.Add(khungDanhSachCanhBao, 0, 1);
            return khung;
        }

        private Control TaoThanhTrangThaiDuoi()
        {
            TableLayoutPanel footer = new TableLayoutPanel();
            footer.Dock = DockStyle.Fill;
            footer.BackColor = Color.White;
            footer.ColumnCount = 4;
            footer.RowCount = 1;
            footer.Padding = new Padding(24, 8, 24, 8);
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
            footer.Controls.Add(TaoMucFooter("▭", "4", "giường đang theo dõi"), 0, 0);
            footer.Controls.Add(TaoMucFooter("▥", "2", "phòng"), 1, 0);
            footer.Controls.Add(TaoMucFooter("⌁", "1", "gateway online"), 2, 0);
            footer.Controls.Add(TaoMucFooter("◷", DateTime.Now.ToString("HH:mm:ss"), DateTime.Now.ToString("dd/MM/yyyy")), 3, 0);
            return footer;
        }

        private Control TaoMucFooter(string icon, string so, string moTa)
        {
            Label lbl = new Label();
            lbl.Dock = DockStyle.Fill;
            lbl.TextAlign = ContentAlignment.MiddleCenter;
            lbl.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            lbl.ForeColor = Color.FromArgb(27, 100, 190);
            lbl.Text = icon + "  " + so + "  " + moTa;
            return lbl;
        }
        private void TaoBonGiuongBenh()
        {
            ThemHoacCapNhatGiuong(new BedData("Giường 01", "Phòng 01", "NGUY CẤP", 84, 72, 38.6, 23, DateTime.Now));
            ThemHoacCapNhatGiuong(new BedData("Giường 02", "Phòng 01", "CẢNH BÁO", 90, 70, 37.8, 24, DateTime.Now));
            ThemHoacCapNhatGiuong(new BedData("Giường 03", "Phòng 02", "CẢNH BÁO", 98, 118, 37.5, 35, DateTime.Now));
            ThemHoacCapNhatGiuong(new BedData("Giường 04", "Phòng 02", "ỔN ĐỊNH", 97, 81, 36.8, 28, DateTime.Now));
        }

        private void KhoiDongNhanDuLieu()
        {
            boNhanDuLieu.Start();
        }

        private void KhoiDongApiServer()
        {
            apiServer = new ApiServer(8080, LayDanhSachGiuongApi, LayDanhSachCanhBaoApi, XacNhanCanhBaoApi, DangKyMobileToken, HienThiTrangThaiApi);
            apiServer.Start();
        }

        private IReadOnlyList<BedData> LayDanhSachGiuongApi()
        {
            lock (apiDataLock)
            {
                return apiBeds.Values.ToList();
            }
        }

        private IReadOnlyList<AlertData> LayDanhSachCanhBaoApi()
        {
            lock (apiDataLock)
            {
                return apiAlerts.ToList();
            }
        }

        private void XacNhanCanhBaoApi(string id)
        {
            lock (apiDataLock)
            {
                AlertData? alert = apiAlerts.FirstOrDefault(item => item.Id == id);
                if (alert != null)
                {
                    alert.Acknowledged = true;
                }
            }
        }

        private void DangKyMobileToken(string token)
        {
            fcmPushService.RegisterToken(token);
            HienThiTrangThaiApi($"Đã đăng ký FCM token từ app Android ({fcmPushService.TokenCount} thiết bị).");
        }

        private void CapNhatGiuongApi(BedData duLieu)
        {
            lock (apiDataLock)
            {
                apiBeds[duLieu.MaGiuong] = duLieu;
            }
        }

        private AlertData ThemCanhBaoApi(BedData duLieu, string noiDung, DateTime thoiGianCanhBao)
        {
            AlertData alert;
            lock (apiDataLock)
            {
                alertCounter++;
                alert = new AlertData(
                    "alert-" + alertCounter.ToString("000"),
                    duLieu.MaGiuong,
                    duLieu.Phong,
                    duLieu.TrangThai,
                    noiDung,
                    duLieu.Spo2,
                    duLieu.NhipTim,
                    duLieu.NhietDo,
                    duLieu.TocDoNhoGiot,
                    thoiGianCanhBao);

                apiAlerts.Add(alert);
            }

            _ = fcmPushService.SendAlertAsync(alert);
            return alert;
        }

        private void HienThiTrangThaiApi(string thongBao)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new Action(() => HienThiTrangThaiApi(thongBao)));
                return;
            }

            lblTrangThaiKetNoi.Text = thongBao;
            lblTrangThaiKetNoi.ForeColor = thongBao.StartsWith("Lỗi", StringComparison.OrdinalIgnoreCase)
                ? Color.FromArgb(220, 60, 60)
                : Color.FromArgb(30, 160, 80);
            manHinhDashboard.SetConnectionStatus(thongBao, !thongBao.StartsWith("Lỗi", StringComparison.OrdinalIgnoreCase));
        }

        private void KhoiDongCloudflared()
        {
            try
            {
                string cloudflaredPath = TimCloudflaredPath();
                if (string.IsNullOrWhiteSpace(cloudflaredPath) || !File.Exists(cloudflaredPath))
                {
                    HienThiTrangThaiApi("Không tìm thấy cloudflared.exe tại " + cloudflaredPath);
                    return;
                }

                ProcessStartInfo startInfo = new ProcessStartInfo
                {
                    FileName = cloudflaredPath,
                    Arguments = "tunnel run khanhquan-lol-api",
                    WorkingDirectory = Path.GetDirectoryName(cloudflaredPath) ?? Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    WindowStyle = ProcessWindowStyle.Hidden,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };

                startInfo.Environment["USERPROFILE"] = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);

                cloudflaredProcess = new Process
                {
                    StartInfo = startInfo,
                    EnableRaisingEvents = true
                };

                cloudflaredProcess.OutputDataReceived += (s, e) => XuLyLogCloudflared(e.Data);
                cloudflaredProcess.ErrorDataReceived += (s, e) => XuLyLogCloudflared(e.Data);
                cloudflaredProcess.Exited += (s, e) =>
                {
                    int exitCode = cloudflaredProcess?.ExitCode ?? -1;
                    HienThiTrangThaiApi("Cloudflare Tunnel đã dừng. ExitCode=" + exitCode);
                };

                if (!cloudflaredProcess.Start())
                {
                    HienThiTrangThaiApi("Không khởi động được cloudflared");
                    return;
                }

                cloudflaredProcess.BeginOutputReadLine();
                cloudflaredProcess.BeginErrorReadLine();
                HienThiTrangThaiApi("HTTP API 8080 + Cloudflare Tunnel đang khởi động...");
            }
            catch (Exception ex)
            {
                HienThiTrangThaiApi("Lỗi chạy cloudflared: " + ex.Message);
            }
        }

        private void XuLyLogCloudflared(string? dongLog)
        {
            if (string.IsNullOrWhiteSpace(dongLog))
            {
                return;
            }

            if (dongLog.Contains("Registered tunnel connection", StringComparison.OrdinalIgnoreCase) ||
                dongLog.Contains("Connection registered", StringComparison.OrdinalIgnoreCase))
            {
                HienThiTrangThaiApi("HTTP API 8080 + Cloudflare Tunnel đang chạy");
                return;
            }

            if (dongLog.Contains("error", StringComparison.OrdinalIgnoreCase) ||
                dongLog.Contains("failed", StringComparison.OrdinalIgnoreCase))
            {
                HienThiTrangThaiApi("Cloudflared: " + dongLog);
            }
        }
        private string TimCloudflaredPath()
        {
            string localPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                ".cloudflared",
                "bin",
                "cloudflared.exe");

            if (File.Exists(localPath))
            {
                return localPath;
            }

            return "cloudflared.exe";
        }

        private void DungCloudflared()
        {
            try
            {
                if (cloudflaredProcess != null && !cloudflaredProcess.HasExited)
                {
                    cloudflaredProcess.Kill(entireProcessTree: true);
                }

                cloudflaredProcess?.Dispose();
            }
            catch
            {
            }
        }
        private void KhoiDongKiemTraKetNoi()
        {
            timerKiemTraKetNoi.Interval = 1000;
            timerKiemTraKetNoi.Tick += (s, e) => KiemTraTrangThaiKetNoi();
            timerKiemTraKetNoi.Start();
        }

        private void KiemTraTrangThaiKetNoi()
        {
            DateTime thoiGianHienTai = DateTime.Now;

            foreach (BedData duLieu in duLieuGiuongHienTai.Values.ToList())
            {
                TimeSpan khoangThoiGian = thoiGianHienTai - duLieu.ThoiGianCapNhat;

                if (khoangThoiGian.TotalSeconds > 3 && duLieu.TrangThai != "NGOẠI TUYẾN")
                {
                    BedData duLieuNgoaiTuyen = duLieu.WithStatus("NGOẠI TUYẾN");
                    duLieuGiuongHienTai[duLieu.MaGiuong] = duLieuNgoaiTuyen;
                    manHinhGiuong.MarkOffline(duLieuNgoaiTuyen);
                    manHinhDashboard.UpdateBeds(duLieuGiuongHienTai.Values);
                    CapNhatGiuongApi(duLieuNgoaiTuyen);
                }
            }

            CapNhatThongKe();
        }

        private void ChuyenGiuongSangNgoaiTuyen(BedCardView theGiuong, BedData duLieuCu)
        {
            if (duLieuCu.TrangThai == "NGOẠI TUYẾN")
            {
                return;
            }

            BedData duLieuNgoaiTuyen = duLieuCu.WithStatus("NGOẠI TUYẾN");

            theGiuong.KhungThe.Tag = duLieuNgoaiTuyen;
            theGiuong.VachMau.BackColor = Color.Gray;

            theGiuong.LblTrangThai.Text = "NGOẠI TUYẾN";
            theGiuong.LblTrangThai.ForeColor = Color.Gray;

            theGiuong.LblKetNoi.Text = "● Mất kết nối";
            theGiuong.LblKetNoi.ForeColor = Color.Gray;
            AnChiSoSinhTon(theGiuong);
            CapNhatGiuongApi(duLieuNgoaiTuyen);
        }

        private void XuLyDuLieuMoi(object? sender, BedData duLieu)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new Action(() => XuLyDuLieuMoi(sender, duLieu)));
                return;
            }

            BedData duLieuCoTrangThai = duLieu.WithStatus(TinhTrangThai(duLieu));
            LuuSinhTonNeuDenChuKy(duLieuCoTrangThai);
            ThemHoacCapNhatGiuong(duLieuCoTrangThai);
        }

        private void HienThiLoiNhanDuLieu(object? sender, string loi)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new Action(() => HienThiLoiNhanDuLieu(sender, loi)));
                return;
            }

            lblTrangThaiKetNoi.Text = loi;
            lblTrangThaiKetNoi.ForeColor = Color.FromArgb(220, 60, 60);
            manHinhDashboard.SetConnectionStatus(loi, false);
        }

        private void ThemHoacCapNhatGiuong(BedData duLieu)
        {
            duLieuGiuongHienTai[duLieu.MaGiuong] = duLieu;
            manHinhGiuong.UpsertBed(duLieu);
            manHinhDashboard.UpdateBeds(duLieuGiuongHienTai.Values);
            CapNhatGiuongApi(duLieu);
            CapNhatCanhBao(duLieu);
            CapNhatThongKe();

            // Cập nhật lên màn hình HTML mới
            if (webView != null && webView.CoreWebView2 != null)
            {
                var htmlBeds = duLieuGiuongHienTai.Values.Select(b => new {
                    id = b.MaGiuong,
                    room = b.Phong,
                    status = b.TrangThai,
                    message = TaoNoiDungCanhBao(b),
                    spo2 = b.Spo2,
                    hr = b.NhipTim,
                    temp = b.NhietDo,
                    drip = b.TocDoNhoGiot,
                    online = b.TrangThai != "NGOẠI TUYẾN",
                    updated = b.ThoiGianCapNhat.ToString("HH:mm:ss")
                }).ToList();
                
                string json = JsonSerializer.Serialize(htmlBeds);
                webView.CoreWebView2.ExecuteScriptAsync($"if(window.updateBeds) window.updateBeds({json});");
            }
        }

        private BedCardView TaoTheGiuongBenh(BedData duLieu)
        {
            Panel the = new Panel();
            the.Height = 188;
            the.Width = 470;
            the.Margin = new Padding(8);
            the.BackColor = Color.White;
            the.BorderStyle = BorderStyle.FixedSingle;

            Panel vachMau = new Panel();
            vachMau.Dock = DockStyle.Top;
            vachMau.Height = 4;
            the.Controls.Add(vachMau);

            TableLayoutPanel boCucThe = new TableLayoutPanel();
            boCucThe.Dock = DockStyle.Fill;
            boCucThe.Padding = new Padding(14, 10, 14, 8);
            boCucThe.RowCount = 3;
            boCucThe.ColumnCount = 1;
            boCucThe.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
            boCucThe.RowStyles.Add(new RowStyle(SizeType.Absolute, 88));
            boCucThe.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            the.Controls.Add(boCucThe);

            TableLayoutPanel dongTieuDe = new TableLayoutPanel();
            dongTieuDe.Dock = DockStyle.Fill;
            dongTieuDe.ColumnCount = 4;
            dongTieuDe.RowCount = 1;
            dongTieuDe.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 46));
            dongTieuDe.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            dongTieuDe.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 92));
            dongTieuDe.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 88));

            Label icon = new Label();
            icon.Text = "▭";
            icon.Font = new Font("Segoe UI Symbol", 17, FontStyle.Bold);
            icon.ForeColor = Color.FromArgb(36, 123, 230);
            icon.BackColor = Color.FromArgb(232, 242, 255);
            icon.TextAlign = ContentAlignment.MiddleCenter;
            icon.Dock = DockStyle.Fill;
            icon.Margin = new Padding(0, 4, 10, 4);

            TableLayoutPanel tenVaPhong = new TableLayoutPanel();
            tenVaPhong.Dock = DockStyle.Fill;
            tenVaPhong.RowCount = 2;
            tenVaPhong.ColumnCount = 1;
            tenVaPhong.RowStyles.Add(new RowStyle(SizeType.Percent, 55));
            tenVaPhong.RowStyles.Add(new RowStyle(SizeType.Percent, 45));

            Label lblGiuong = TaoNhan(duLieu.MaGiuong, 11, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            Label lblPhong = TaoNhan(duLieu.Phong, 8, FontStyle.Regular, Color.FromArgb(83, 98, 119));
            lblGiuong.Dock = DockStyle.Fill;
            lblGiuong.TextAlign = ContentAlignment.BottomLeft;
            lblPhong.Dock = DockStyle.Fill;
            lblPhong.TextAlign = ContentAlignment.TopLeft;
            tenVaPhong.Controls.Add(lblGiuong, 0, 0);
            tenVaPhong.Controls.Add(lblPhong, 0, 1);

            Label lblPhongChip = TaoNhan(duLieu.Phong, 8, FontStyle.Bold, Color.FromArgb(32, 112, 200));
            lblPhongChip.BackColor = Color.FromArgb(232, 242, 255);
            lblPhongChip.TextAlign = ContentAlignment.MiddleCenter;
            lblPhongChip.Dock = DockStyle.Fill;
            lblPhongChip.Margin = new Padding(6, 10, 6, 10);

            Label lblTrangThai = TaoNhan(duLieu.TrangThai, 8, FontStyle.Bold, Color.Gray);
            lblTrangThai.TextAlign = ContentAlignment.MiddleCenter;
            lblTrangThai.Dock = DockStyle.Fill;
            lblTrangThai.Margin = new Padding(4, 10, 0, 10);

            dongTieuDe.Controls.Add(icon, 0, 0);
            dongTieuDe.Controls.Add(tenVaPhong, 1, 0);
            dongTieuDe.Controls.Add(lblPhongChip, 2, 0);
            dongTieuDe.Controls.Add(lblTrangThai, 3, 0);

            TableLayoutPanel dongChiSo = new TableLayoutPanel();
            dongChiSo.Dock = DockStyle.Fill;
            dongChiSo.ColumnCount = 4;
            dongChiSo.RowCount = 1;
            dongChiSo.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
            dongChiSo.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
            dongChiSo.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
            dongChiSo.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));

            MetricView spo2 = TaoOChiSo("SpO₂", "♢");
            MetricView nhipTim = TaoOChiSo("Nhịp tim", "♡");
            MetricView nhietDo = TaoOChiSo("Nhiệt độ", "♨");
            MetricView nhoGiot = TaoOChiSo("Nhỏ giọt", "♢");

            dongChiSo.Controls.Add(spo2.Khung, 0, 0);
            dongChiSo.Controls.Add(nhipTim.Khung, 1, 0);
            dongChiSo.Controls.Add(nhietDo.Khung, 2, 0);
            dongChiSo.Controls.Add(nhoGiot.Khung, 3, 0);

            TableLayoutPanel dongTrangThai = new TableLayoutPanel();
            dongTrangThai.Dock = DockStyle.Fill;
            dongTrangThai.ColumnCount = 2;
            dongTrangThai.RowCount = 1;
            dongTrangThai.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 52));
            dongTrangThai.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 48));

            Label lblKetNoi = TaoNhan("● Đang kết nối", 8, FontStyle.Bold, Color.FromArgb(30, 160, 80));
            Label lblCapNhat = TaoNhan("Cập nhật: vừa xong", 8, FontStyle.Regular, Color.FromArgb(80, 96, 115));
            lblKetNoi.TextAlign = ContentAlignment.MiddleLeft;
            lblCapNhat.TextAlign = ContentAlignment.MiddleRight;
            lblKetNoi.Dock = DockStyle.Fill;
            lblCapNhat.Dock = DockStyle.Fill;

            dongTrangThai.Controls.Add(lblKetNoi, 0, 0);
            dongTrangThai.Controls.Add(lblCapNhat, 1, 0);

            boCucThe.Controls.Add(dongTieuDe, 0, 0);
            boCucThe.Controls.Add(dongChiSo, 0, 1);
            boCucThe.Controls.Add(dongTrangThai, 0, 2);

            return new BedCardView(the, vachMau, lblGiuong, lblPhongChip, lblTrangThai, spo2, nhipTim, nhietDo, nhoGiot, lblKetNoi, lblCapNhat);
        }

        private MetricView TaoOChiSo(string tenChiSo, string icon)
        {
            Panel o = new Panel();
            o.Dock = DockStyle.Fill;
            o.Padding = new Padding(8, 7, 8, 5);
            o.Margin = new Padding(4, 8, 4, 8);
            o.BackColor = Color.FromArgb(248, 251, 255);

            TableLayoutPanel boCuc = new TableLayoutPanel();
            boCuc.Dock = DockStyle.Fill;
            boCuc.RowCount = 2;
            boCuc.ColumnCount = 1;
            boCuc.RowStyles.Add(new RowStyle(SizeType.Absolute, 28));
            boCuc.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            o.Controls.Add(boCuc);

            Label lblTen = new Label();
            lblTen.Text = icon + "  " + tenChiSo;
            lblTen.Font = new Font("Segoe UI", 7, FontStyle.Regular);
            lblTen.ForeColor = Color.FromArgb(85, 100, 120);
            lblTen.Dock = DockStyle.Fill;
            lblTen.TextAlign = ContentAlignment.BottomCenter;

            Label lblGiaTri = new Label();
            lblGiaTri.Text = "--";
            lblGiaTri.Font = new Font("Segoe UI", 13, FontStyle.Bold);
            lblGiaTri.ForeColor = Color.Gray;
            lblGiaTri.Dock = DockStyle.Fill;
            lblGiaTri.TextAlign = ContentAlignment.TopCenter;

            boCuc.Controls.Add(lblTen, 0, 0);
            boCuc.Controls.Add(lblGiaTri, 0, 1);
            return new MetricView(o, lblGiaTri);
        }
        private void CapNhatTheGiuong(BedCardView theGiuong, BedData duLieu)
        {
            Color mauTrangThai = LayMauTrangThai(duLieu.TrangThai);

            theGiuong.KhungThe.Tag = duLieu;
            theGiuong.VachMau.BackColor = mauTrangThai;
            theGiuong.LblGiuong.Text = duLieu.MaGiuong;
            theGiuong.LblPhong.Text = duLieu.Phong;
            theGiuong.LblTrangThai.Text = duLieu.TrangThai;
            theGiuong.LblTrangThai.ForeColor = mauTrangThai;
            if (duLieu.TrangThai == "NGOẠI TUYẾN")
            {
                AnChiSoSinhTon(theGiuong);
                theGiuong.LblKetNoi.Text = "● Mất kết nối";
                theGiuong.LblKetNoi.ForeColor = Color.Gray;
                theGiuong.LblCapNhat.Text = duLieu.ThoiGianCapNhat.ToString("HH:mm:ss");
                return;
            }

            theGiuong.Spo2.GiaTri.Text = duLieu.Spo2 + "%";
            theGiuong.Spo2.GiaTri.ForeColor = LayMauSpo2(duLieu.Spo2);
            theGiuong.NhipTim.GiaTri.Text = duLieu.NhipTim.ToString();
            theGiuong.NhipTim.GiaTri.ForeColor = LayMauNhipTim(duLieu.NhipTim);
            theGiuong.NhietDo.GiaTri.Text = duLieu.NhietDo.ToString("0.0") + "°C";
            theGiuong.NhietDo.GiaTri.ForeColor = LayMauNhietDo(duLieu.NhietDo);
            theGiuong.NhoGiot.GiaTri.Text = duLieu.TocDoNhoGiot + "/phút";
            theGiuong.NhoGiot.GiaTri.ForeColor = Color.FromArgb(30, 160, 80);
            theGiuong.LblKetNoi.Text = "● Đang kết nối";
            theGiuong.LblKetNoi.ForeColor = Color.FromArgb(30, 160, 80);
            theGiuong.LblCapNhat.Text = duLieu.ThoiGianCapNhat.ToString("HH:mm:ss");
        }

        private void AnChiSoSinhTon(BedCardView theGiuong)
        {
            theGiuong.Spo2.GiaTri.Text = "--";
            theGiuong.Spo2.GiaTri.ForeColor = Color.Gray;
            theGiuong.NhipTim.GiaTri.Text = "--";
            theGiuong.NhipTim.GiaTri.ForeColor = Color.Gray;
            theGiuong.NhietDo.GiaTri.Text = "--";
            theGiuong.NhietDo.GiaTri.ForeColor = Color.Gray;
            theGiuong.NhoGiot.GiaTri.Text = "--";
            theGiuong.NhoGiot.GiaTri.ForeColor = Color.Gray;
        }

        private void CapNhatCanhBao(BedData duLieu)
        {
            if (duLieu.TrangThai == "ỔN ĐỊNH" || duLieu.TrangThai == "NGOẠI TUYẾN")
            {
                return;
            }

            string noiDung = TaoNoiDungCanhBao(duLieu);
            ThemCanhBao(duLieu, noiDung);
        }

        private void ThemCanhBao(BedData duLieu, string noiDung)
        {
            DateTime thoiGianCanhBao = DateTime.Now;
            ThemCanhBaoApi(duLieu, noiDung, thoiGianCanhBao);
            _ = LuuCanhBaoVaoMySqlAsync(duLieu, noiDung, thoiGianCanhBao);

            if (khungDanhSachCanhBao == null || khungDanhSachCanhBao.IsDisposed)
            {
                return;
            }

            Color mau = LayMauTrangThai(duLieu.TrangThai);

            Panel item = new Panel();
            item.Width = 300;
            item.Height = 96;
            item.Margin = new Padding(4, 7, 4, 7);
            item.BackColor = Color.FromArgb(252, 253, 255);
            item.BorderStyle = BorderStyle.FixedSingle;

            Panel vachMau = new Panel();
            vachMau.Dock = DockStyle.Left;
            vachMau.Width = 34;
            vachMau.BackColor = mau;
            item.Controls.Add(vachMau);

            Label icon = new Label();
            icon.Text = duLieu.TrangThai == "NGUY CẤP" ? "⚕" : "⚠";
            icon.Font = new Font("Segoe UI Symbol", 14, FontStyle.Bold);
            icon.ForeColor = Color.White;
            icon.Dock = DockStyle.Fill;
            icon.TextAlign = ContentAlignment.MiddleCenter;
            vachMau.Controls.Add(icon);

            TableLayoutPanel boCuc = new TableLayoutPanel();
            boCuc.Dock = DockStyle.Fill;
            boCuc.Padding = new Padding(46, 8, 10, 8);
            boCuc.ColumnCount = 2;
            boCuc.RowCount = 1;
            boCuc.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            boCuc.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 74));
            item.Controls.Add(boCuc);

            TableLayoutPanel noiDungTrai = new TableLayoutPanel();
            noiDungTrai.Dock = DockStyle.Fill;
            noiDungTrai.RowCount = 4;
            noiDungTrai.ColumnCount = 1;
            noiDungTrai.RowStyles.Add(new RowStyle(SizeType.Absolute, 18));
            noiDungTrai.RowStyles.Add(new RowStyle(SizeType.Absolute, 24));
            noiDungTrai.RowStyles.Add(new RowStyle(SizeType.Absolute, 22));
            noiDungTrai.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            Label lblMucDo = TaoNhan(duLieu.TrangThai, 8, FontStyle.Bold, mau);
            Label lblGiuong = TaoNhan(duLieu.MaGiuong, 10, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            Label lblNoiDung = TaoNhan(noiDung, 8, FontStyle.Regular, Color.FromArgb(82, 97, 116));
            Label lblThoiGian = TaoNhan("◷  " + thoiGianCanhBao.ToString("HH:mm:ss dd/MM/yyyy"), 7, FontStyle.Regular, Color.FromArgb(95, 110, 130));
            lblMucDo.Dock = DockStyle.Fill;
            lblGiuong.Dock = DockStyle.Fill;
            lblNoiDung.Dock = DockStyle.Fill;
            lblThoiGian.Dock = DockStyle.Fill;

            noiDungTrai.Controls.Add(lblMucDo, 0, 0);
            noiDungTrai.Controls.Add(lblGiuong, 0, 1);
            noiDungTrai.Controls.Add(lblNoiDung, 0, 2);
            noiDungTrai.Controls.Add(lblThoiGian, 0, 3);

            TableLayoutPanel nutPanel = new TableLayoutPanel();
            nutPanel.Dock = DockStyle.Fill;
            nutPanel.RowCount = 2;
            nutPanel.ColumnCount = 1;
            nutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
            nutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 50));

            Button xem = TaoNutHanhDong("Xem");
            xem.Dock = DockStyle.Fill;
            xem.Margin = new Padding(4, 0, 0, 4);
            xem.Click += (s, e) =>
            {
                string chiTiet =
                    "THÔNG TIN CẢNH BÁO\n\n" +
                    "Giường bệnh: " + duLieu.MaGiuong + "\n" +
                    "Phòng: " + duLieu.Phong + "\n" +
                    "Mức độ: " + duLieu.TrangThai + "\n" +
                    "Thời gian cảnh báo: " + thoiGianCanhBao.ToString("HH:mm:ss dd/MM/yyyy") + "\n\n" +
                    "SpO₂: " + duLieu.Spo2 + "%\n" +
                    "Nhịp tim: " + duLieu.NhipTim + "\n" +
                    "Nhiệt độ: " + duLieu.NhietDo.ToString("0.0") + "°C\n" +
                    "Tốc độ nhỏ giọt: " + duLieu.TocDoNhoGiot + "/phút\n\n" +
                    "Nội dung: " + noiDung;

                MessageBox.Show(chiTiet, "Chi tiết cảnh báo - " + duLieu.MaGiuong, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            };

            Button xacNhan = TaoNutHanhDong("Xác nhận");
            xacNhan.Dock = DockStyle.Fill;
            xacNhan.Margin = new Padding(4, 4, 0, 0);
            xacNhan.BackColor = mau;
            xacNhan.ForeColor = Color.White;
            xacNhan.Click += (s, e) => item.Dispose();

            nutPanel.Controls.Add(xem, 0, 0);
            nutPanel.Controls.Add(xacNhan, 0, 1);
            boCuc.Controls.Add(noiDungTrai, 0, 0);
            boCuc.Controls.Add(nutPanel, 1, 0);

            khungDanhSachCanhBao.Controls.Add(item);
            khungDanhSachCanhBao.Controls.SetChildIndex(item, 0);
        }
        private void CapNhatThongKe()
        {
            List<BedData> duLieu = duLieuGiuongHienTai.Values.ToList();

            if (nhanThongKe.Count == 0)
            {
                return;
            }

            nhanThongKe["Giường"].Text = duLieu.Count.ToString();
            nhanThongKe["Nguy cấp"].Text = duLieu.Count(x => x.TrangThai == "NGUY CẤP").ToString();
            nhanThongKe["Cảnh báo"].Text = duLieu.Count(x => x.TrangThai == "CẢNH BÁO").ToString();
            nhanThongKe["Ngoại tuyến"].Text = duLieu.Count(x => x.TrangThai == "NGOẠI TUYẾN").ToString();
        }

        private async Task LuuSinhTonVaoMySqlAsync(BedData duLieu)
        {
            try
            {
                await historyRepository.SaveVitalSampleAsync(duLieu);
            }
            catch (Exception ex)
            {
                HienThiLoiNhanDuLieu(this, "Không lưu được lịch sử MySQL: " + ex.Message);
            }
        }

        private void LuuSinhTonNeuDenChuKy(BedData duLieu)
        {
            DateTime bayGio = DateTime.Now;
            if (lanLuuSinhTonGanNhat.TryGetValue(duLieu.MaGiuong, out DateTime lanCu)
                && (bayGio - lanCu).TotalSeconds < chuKyLuuSinhTonGiay)
            {
                return;
            }

            lanLuuSinhTonGanNhat[duLieu.MaGiuong] = bayGio;
            _ = LuuSinhTonVaoMySqlAsync(duLieu);
        }

        private void HienThiCauHinhChuKyLuuSql()
        {
            using Form dialog = new Form();
            dialog.Text = "Cấu hình lưu MySQL";
            dialog.StartPosition = FormStartPosition.CenterParent;
            dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
            dialog.MinimizeBox = false;
            dialog.MaximizeBox = false;
            dialog.ClientSize = new Size(360, 168);
            dialog.BackColor = Color.White;

            Label title = new Label
            {
                Text = "Chu kỳ lưu chỉ số sinh tồn vào MySQL",
                Location = new Point(18, 18),
                Size = new Size(320, 24),
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                ForeColor = Color.FromArgb(18, 43, 73)
            };
            dialog.Controls.Add(title);

            Label note = new Label
            {
                Text = "Giao diện và cảnh báo vẫn cập nhật thời gian thực.",
                Location = new Point(18, 46),
                Size = new Size(320, 22),
                Font = new Font("Segoe UI", 8),
                ForeColor = Color.FromArgb(95, 110, 130)
            };
            dialog.Controls.Add(note);

            NumericUpDown input = new NumericUpDown
            {
                Location = new Point(18, 82),
                Size = new Size(110, 28),
                Minimum = 1,
                Maximum = 3600,
                Value = chuKyLuuSinhTonGiay,
                Font = new Font("Segoe UI", 10)
            };
            dialog.Controls.Add(input);

            Label unit = new Label
            {
                Text = "giây / lần / giường",
                Location = new Point(138, 84),
                Size = new Size(180, 24),
                Font = new Font("Segoe UI", 9),
                ForeColor = Color.FromArgb(18, 43, 73)
            };
            dialog.Controls.Add(unit);

            Button ok = new Button
            {
                Text = "Lưu",
                DialogResult = DialogResult.OK,
                Location = new Point(178, 124),
                Size = new Size(76, 30),
                BackColor = Color.FromArgb(0, 99, 255),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            dialog.Controls.Add(ok);

            Button cancel = new Button
            {
                Text = "Hủy",
                DialogResult = DialogResult.Cancel,
                Location = new Point(264, 124),
                Size = new Size(76, 30),
                FlatStyle = FlatStyle.Flat
            };
            dialog.Controls.Add(cancel);

            dialog.AcceptButton = ok;
            dialog.CancelButton = cancel;

            if (dialog.ShowDialog(this) == DialogResult.OK)
            {
                chuKyLuuSinhTonGiay = (int)input.Value;
                manHinhGiuong.SetSaveInterval(chuKyLuuSinhTonGiay);
            }
        }

        private async Task LuuCanhBaoVaoMySqlAsync(BedData duLieu, string noiDung, DateTime thoiGianCanhBao)
        {
            try
            {
                await historyRepository.SaveAlertAsync(duLieu, noiDung, thoiGianCanhBao);
                if (manHinhCanhBao != null && !manHinhCanhBao.IsDisposed)
                {
                    await manHinhCanhBao.RefreshFromDatabaseAsync();
                }
            }
            catch (Exception ex)
            {
                HienThiLoiNhanDuLieu(this, "Không lưu được cảnh báo MySQL: " + ex.Message);
            }
        }

        private void ApDungBoLoc(string tuKhoa)
        {
            // Bộ lọc giường bệnh đã được chuyển sang BedManagementView.
        }

        private string TinhTrangThai(BedData duLieu)
        {
            if (!string.IsNullOrWhiteSpace(duLieu.TrangThai))
            {
                return duLieu.TrangThai.ToUpperInvariant();
            }

            if (duLieu.Spo2 < 90 || duLieu.NhietDo >= 38.0)
            {
                return "NGUY CẤP";
            }

            if (duLieu.Spo2 < 95 || duLieu.NhipTim < 60 || duLieu.NhipTim > 110 || duLieu.NhietDo >= 37.5)
            {
                return "CẢNH BÁO";
            }

            return "ỔN ĐỊNH";
        }

        private string TaoNoiDungCanhBao(BedData duLieu)
        {
            if (!string.IsNullOrWhiteSpace(duLieu.MoTaCanhBao))
            {
                return duLieu.MoTaCanhBao;
            }

            if (duLieu.Spo2 < 95)
            {
                return "SpO₂ thấp: " + duLieu.Spo2 + "%";
            }

            if (duLieu.NhietDo >= 37.5)
            {
                return "Nhiệt độ cao: " + duLieu.NhietDo.ToString("0.0") + "°C";
            }

            if (duLieu.NhipTim < 60 || duLieu.NhipTim > 110)
            {
                return "Nhịp tim bất thường: " + duLieu.NhipTim;
            }

            return "Cần kiểm tra chỉ số";
        }

        private Label TaoNhan(string noiDung, int coChu, FontStyle kieuChu, Color mau)
        {
            Label nhan = new Label();
            nhan.Text = noiDung;
            nhan.Font = new Font("Segoe UI", coChu, kieuChu);
            nhan.ForeColor = mau;
            nhan.AutoSize = false;
            return nhan;
        }

        private void DieuChinhKichThuocThe()
        {
            // Card giường hiện tự resize trong BedManagementView.
        }
        private void DieuChinhKichThuocCanhBao()
        {
            if (khungDanhSachCanhBao == null)
            {
                return;
            }

            int chieuRong = khungDanhSachCanhBao.ClientSize.Width - 25;

            if (chieuRong < 230)
            {
                chieuRong = 230;
            }

            foreach (Control item in khungDanhSachCanhBao.Controls)
            {
                item.Width = chieuRong;
            }
        }

        private Color LayMauTrangThai(string trangThai)
        {
            if (trangThai == "NGUY CẤP")
            {
                return Color.FromArgb(220, 60, 60);
            }

            if (trangThai == "CẢNH BÁO")
            {
                return Color.FromArgb(230, 145, 25);
            }

            if (trangThai == "ỔN ĐỊNH")
            {
                return Color.FromArgb(30, 160, 80);
            }

            return Color.Gray;
        }

        private Color LayMauSpo2(int spo2)
        {
            if (spo2 < 90)
            {
                return Color.FromArgb(220, 60, 60);
            }

            if (spo2 < 95)
            {
                return Color.FromArgb(230, 145, 25);
            }

            return Color.FromArgb(30, 160, 80);
        }

        private Color LayMauNhipTim(int nhipTim)
        {
            if (nhipTim < 60 || nhipTim > 110)
            {
                return Color.FromArgb(230, 145, 25);
            }

            return Color.FromArgb(30, 160, 80);
        }

        private Color LayMauNhietDo(double nhietDo)
        {
            if (nhietDo >= 38.0)
            {
                return Color.FromArgb(220, 60, 60);
            }

            if (nhietDo >= 37.5)
            {
                return Color.FromArgb(230, 145, 25);
            }

            return Color.FromArgb(30, 160, 80);
        }

        private sealed record MetricView(Panel Khung, Label GiaTri);

        private sealed record BedCardView(
            Panel KhungThe,
            Panel VachMau,
            Label LblGiuong,
            Label LblPhong,
            Label LblTrangThai,
            MetricView Spo2,
            MetricView NhipTim,
            MetricView NhietDo,
            MetricView NhoGiot,
            Label LblKetNoi,
            Label LblCapNhat);
    }
}
