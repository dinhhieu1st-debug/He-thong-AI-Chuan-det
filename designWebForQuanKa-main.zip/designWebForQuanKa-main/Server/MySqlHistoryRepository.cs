using MySql.Data.MySqlClient;

namespace Server
{
    public sealed class MySqlHistoryRepository
    {
        private const string DefaultConnectionString =
            "Server=localhost;Port=3306;Database=fpt_hospital_monitoring;Uid=root;Pwd=;SslMode=None;AllowPublicKeyRetrieval=True;";

        private readonly List<string> connectionStrings;

        public MySqlHistoryRepository()
        {
            string? configuredConnectionString = Environment.GetEnvironmentVariable("FPT_MYSQL_CONNECTION");
            connectionStrings = new List<string>();
            if (string.IsNullOrWhiteSpace(configuredConnectionString))
            {
                connectionStrings.Add(DefaultConnectionString);
            }
            else
            {
                connectionStrings.Add(configuredConnectionString);
            }

            AddConnectionStringIfMissing(BuildConnectionString(string.Empty));
            AddConnectionStringIfMissing(BuildConnectionString("Root@1234"));
            AddConnectionStringIfMissing(BuildConnectionString("Root@12345"));
            AddConnectionStringIfMissing(BuildConnectionString("Root@123456"));
        }

        public async Task<List<HistoryLogEntry>> LoadHistoryAsync(CancellationToken cancellationToken = default)
        {
            List<HistoryLogEntry> logs = new List<HistoryLogEntry>();

            await using MySqlConnection connection = await OpenConnectionAsync(cancellationToken);

            await LoadAlertsAsync(connection, logs, cancellationToken);
            await LoadVitalSamplesAsync(connection, logs, cancellationToken);

            return logs
                .OrderByDescending(log => log.Time)
                .Take(500)
                .ToList();
        }

        public async Task SaveVitalSampleAsync(BedData bedData, CancellationToken cancellationToken = default)
        {
            const string sql = """
                INSERT INTO vital_samples (
                    bed_id,
                    device_id,
                    spo2,
                    heart_rate,
                    temperature,
                    drip_rate,
                    sample_status,
                    recorded_at
                ) VALUES (
                    @bed_id,
                    @device_id,
                    @spo2,
                    @heart_rate,
                    @temperature,
                    @drip_rate,
                    @sample_status,
                    @recorded_at
                );
                """;

            await using MySqlConnection connection = await OpenConnectionAsync(cancellationToken);
            await using MySqlCommand command = new MySqlCommand(sql, connection);
            AddBedParameters(command, bedData);
            command.Parameters.AddWithValue("@sample_status", ToDatabaseStatus(bedData.TrangThai));
            command.Parameters.AddWithValue("@recorded_at", bedData.ThoiGianCapNhat);
            await command.ExecuteNonQueryAsync(cancellationToken);
        }

        public async Task SaveAlertAsync(BedData bedData, string message, DateTime createdAt, CancellationToken cancellationToken = default)
        {
            const string sql = """
                INSERT INTO alerts (
                    bed_id,
                    device_id,
                    alert_level,
                    alert_type,
                    message,
                    spo2,
                    heart_rate,
                    temperature,
                    drip_rate,
                    acknowledged,
                    created_at
                ) VALUES (
                    @bed_id,
                    @device_id,
                    @alert_level,
                    @alert_type,
                    @message,
                    @spo2,
                    @heart_rate,
                    @temperature,
                    @drip_rate,
                    FALSE,
                    @created_at
                );
                """;

            await using MySqlConnection connection = await OpenConnectionAsync(cancellationToken);
            await using MySqlCommand command = new MySqlCommand(sql, connection);
            AddBedParameters(command, bedData);
            command.Parameters.AddWithValue("@alert_level", ToDatabaseAlertLevel(bedData.TrangThai));
            command.Parameters.AddWithValue("@alert_type", CreateAlertType(bedData));
            command.Parameters.AddWithValue("@message", message);
            command.Parameters.AddWithValue("@created_at", createdAt);
            await command.ExecuteNonQueryAsync(cancellationToken);
        }

        public async Task<List<AlertHistoryEntry>> LoadAlertsAsync(CancellationToken cancellationToken = default)
        {
            const string sql = """
                SELECT
                    alert_id,
                    bed_id,
                    device_id,
                    alert_level,
                    alert_type,
                    message,
                    spo2,
                    heart_rate,
                    temperature,
                    drip_rate,
                    acknowledged,
                    created_at,
                    acknowledged_at
                FROM alerts
                ORDER BY created_at DESC
                LIMIT 500;
                """;

            List<AlertHistoryEntry> alerts = new List<AlertHistoryEntry>();
            await using MySqlConnection connection = await OpenConnectionAsync(cancellationToken);
            await using MySqlCommand command = new MySqlCommand(sql, connection);
            await using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                alerts.Add(new AlertHistoryEntry(
                    Id: GetInt64(reader, "alert_id"),
                    BedId: GetString(reader, "bed_id"),
                    DeviceId: GetString(reader, "device_id"),
                    Level: GetString(reader, "alert_level") == "NGUY_CAP" ? "Nguy cấp" : "Cảnh báo",
                    Type: GetString(reader, "alert_type"),
                    Message: GetString(reader, "message"),
                    Spo2: GetNullableInt32(reader, "spo2"),
                    HeartRate: GetNullableInt32(reader, "heart_rate"),
                    Temperature: GetNullableDecimal(reader, "temperature"),
                    DripRate: GetNullableInt32(reader, "drip_rate"),
                    Acknowledged: GetBool(reader, "acknowledged"),
                    CreatedAt: GetDateTime(reader, "created_at"),
                    AcknowledgedAt: GetNullableDateTime(reader, "acknowledged_at")));
            }

            return alerts;
        }

        public async Task AcknowledgeAlertAsync(long alertId, CancellationToken cancellationToken = default)
        {
            const string sql = """
                UPDATE alerts
                SET acknowledged = TRUE,
                    acknowledged_at = COALESCE(acknowledged_at, NOW())
                WHERE alert_id = @alert_id;
                """;

            await using MySqlConnection connection = await OpenConnectionAsync(cancellationToken);
            await using MySqlCommand command = new MySqlCommand(sql, connection);
            command.Parameters.AddWithValue("@alert_id", alertId);
            await command.ExecuteNonQueryAsync(cancellationToken);
        }

        private static async Task LoadAlertsAsync(MySqlConnection connection, List<HistoryLogEntry> logs, CancellationToken cancellationToken)
        {
            const string sql = """
                SELECT
                    alert_id,
                    bed_id,
                    device_id,
                    alert_level,
                    alert_type,
                    message,
                    spo2,
                    heart_rate,
                    temperature,
                    drip_rate,
                    acknowledged,
                    created_at
                FROM alerts
                ORDER BY created_at DESC
                LIMIT 300;
                """;

            await using MySqlCommand command = new MySqlCommand(sql, connection);
            await using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                string bedId = GetString(reader, "bed_id");
                string deviceId = GetString(reader, "device_id");
                string levelRaw = GetString(reader, "alert_level");
                bool acknowledged = GetBool(reader, "acknowledged");
                DateTime createdAt = GetDateTime(reader, "created_at");

                string level = levelRaw == "NGUY_CAP" ? "Nguy cấp" : "Cảnh báo";
                string message = GetString(reader, "message");
                if (acknowledged)
                {
                    message += " (đã xác nhận)";
                }

                logs.Add(new HistoryLogEntry(
                    Id: "ALERT-" + GetInt64(reader, "alert_id").ToString("D6"),
                    Time: createdAt,
                    Category: "Cảnh báo",
                    Device: FormatDeviceBed(deviceId, bedId),
                    Message: message,
                    Level: level,
                    Related: bedId,
                    Detail: BuildVitalDetail(reader, message)));
            }
        }

        private async Task<MySqlConnection> OpenConnectionAsync(CancellationToken cancellationToken)
        {
            List<string> errors = new List<string>();
            foreach (string candidate in connectionStrings)
            {
                MySqlConnection connection = new MySqlConnection(candidate);
                try
                {
                    await connection.OpenAsync(cancellationToken);
                    return connection;
                }
                catch (Exception ex)
                {
                    errors.Add(ex.Message);
                    await connection.DisposeAsync();
                }
            }

            throw new InvalidOperationException("Không kết nối được MySQL với các mật khẩu đã thử: rỗng, Root@1234, Root@12345, Root@123456. Lỗi cuối: " + errors.LastOrDefault());
        }

        private void AddConnectionStringIfMissing(string candidate)
        {
            if (!connectionStrings.Any(item => string.Equals(item, candidate, StringComparison.OrdinalIgnoreCase)))
            {
                connectionStrings.Add(candidate);
            }
        }

        private static string BuildConnectionString(string password)
        {
            MySqlConnectionStringBuilder builder = new MySqlConnectionStringBuilder
            {
                Server = "localhost",
                Port = 3306,
                Database = "fpt_hospital_monitoring",
                UserID = "root",
                Password = password,
                SslMode = MySqlSslMode.Disabled,
                AllowPublicKeyRetrieval = true
            };

            return builder.ConnectionString;
        }

        private static async Task LoadVitalSamplesAsync(MySqlConnection connection, List<HistoryLogEntry> logs, CancellationToken cancellationToken)
        {
            const string sql = """
                SELECT
                    sample_id,
                    bed_id,
                    device_id,
                    spo2,
                    heart_rate,
                    temperature,
                    drip_rate,
                    sample_status,
                    recorded_at
                FROM vital_samples
                ORDER BY recorded_at DESC
                LIMIT 300;
                """;

            await using MySqlCommand command = new MySqlCommand(sql, connection);
            await using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                string bedId = GetString(reader, "bed_id");
                string deviceId = GetString(reader, "device_id");
                string status = GetString(reader, "sample_status");
                DateTime recordedAt = GetDateTime(reader, "recorded_at");
                string level = MapSampleLevel(status);
                string message = $"Cập nhật sinh tồn: SpO2 {FormatPercent(reader, "spo2")}, nhịp tim {FormatNumber(reader, "heart_rate")}, nhiệt độ {FormatTemperature(reader, "temperature")}, nhỏ giọt {FormatDrip(reader, "drip_rate")}";

                logs.Add(new HistoryLogEntry(
                    Id: "VITAL-" + GetInt64(reader, "sample_id").ToString("D6"),
                    Time: recordedAt,
                    Category: "Sinh tồn",
                    Device: FormatDeviceBed(deviceId, bedId),
                    Message: message,
                    Level: level,
                    Related: bedId,
                    Detail: BuildVitalDetail(reader, message)));
            }
        }

        private static string MapSampleLevel(string status)
        {
            return status switch
            {
                "NGUY_CAP" => "Nguy cấp",
                "CANH_BAO" => "Cảnh báo",
                _ => "Thông tin"
            };
        }

        private static void AddBedParameters(MySqlCommand command, BedData bedData)
        {
            command.Parameters.AddWithValue("@bed_id", bedData.MaGiuong);
            command.Parameters.AddWithValue("@device_id", DBNull.Value);
            command.Parameters.AddWithValue("@spo2", bedData.Spo2);
            command.Parameters.AddWithValue("@heart_rate", bedData.NhipTim);
            command.Parameters.AddWithValue("@temperature", bedData.NhietDo);
            command.Parameters.AddWithValue("@drip_rate", bedData.TocDoNhoGiot);
        }

        private static string ToDatabaseStatus(string status)
        {
            return status switch
            {
                "NGUY CẤP" => "NGUY_CAP",
                "NGUY CAP" => "NGUY_CAP",
                "CẢNH BÁO" => "CANH_BAO",
                "CANH BAO" => "CANH_BAO",
                _ => "ON_DINH"
            };
        }

        private static string ToDatabaseAlertLevel(string status)
        {
            return ToDatabaseStatus(status) == "NGUY_CAP" ? "NGUY_CAP" : "CANH_BAO";
        }

        private static string CreateAlertType(BedData bedData)
        {
            if (bedData.Spo2 < 90)
            {
                return "SPO2_LOW_CRITICAL";
            }

            if (bedData.Spo2 < 95)
            {
                return "SPO2_LOW";
            }

            if (bedData.NhietDo >= 38)
            {
                return "TEMP_HIGH_CRITICAL";
            }

            if (bedData.NhietDo >= 37.5)
            {
                return "TEMP_HIGH";
            }

            if (bedData.NhipTim < 60 || bedData.NhipTim > 110)
            {
                return "HEART_RATE_ABNORMAL";
            }

            return "VITAL_WARNING";
        }

        private static string FormatDeviceBed(string deviceId, string bedId)
        {
            if (!string.IsNullOrWhiteSpace(deviceId) && !string.IsNullOrWhiteSpace(bedId))
            {
                return $"{deviceId} / {bedId}";
            }

            return string.IsNullOrWhiteSpace(deviceId) ? bedId : deviceId;
        }

        private static string BuildVitalDetail(MySqlDataReader reader, string firstLine)
        {
            return firstLine + Environment.NewLine
                + "SpO2: " + FormatPercent(reader, "spo2") + Environment.NewLine
                + "Nhịp tim: " + FormatNumber(reader, "heart_rate") + Environment.NewLine
                + "Nhiệt độ: " + FormatTemperature(reader, "temperature") + Environment.NewLine
                + "Nhỏ giọt: " + FormatDrip(reader, "drip_rate");
        }

        private static string FormatPercent(MySqlDataReader reader, string columnName)
        {
            return reader.IsDBNull(reader.GetOrdinal(columnName)) ? "--" : GetInt32(reader, columnName) + "%";
        }

        private static string FormatNumber(MySqlDataReader reader, string columnName)
        {
            return reader.IsDBNull(reader.GetOrdinal(columnName)) ? "--" : GetInt32(reader, columnName).ToString();
        }

        private static string FormatTemperature(MySqlDataReader reader, string columnName)
        {
            return reader.IsDBNull(reader.GetOrdinal(columnName)) ? "--" : GetDecimal(reader, columnName).ToString("0.0") + " °C";
        }

        private static string FormatDrip(MySqlDataReader reader, string columnName)
        {
            return reader.IsDBNull(reader.GetOrdinal(columnName)) ? "--" : GetInt32(reader, columnName) + "/phút";
        }

        private static string GetString(MySqlDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? string.Empty : reader.GetString(ordinal);
        }

        private static int GetInt32(MySqlDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? 0 : reader.GetInt32(ordinal);
        }

        private static int? GetNullableInt32(MySqlDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? null : reader.GetInt32(ordinal);
        }

        private static long GetInt64(MySqlDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? 0 : reader.GetInt64(ordinal);
        }

        private static decimal GetDecimal(MySqlDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? 0 : reader.GetDecimal(ordinal);
        }

        private static decimal? GetNullableDecimal(MySqlDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? null : reader.GetDecimal(ordinal);
        }

        private static bool GetBool(MySqlDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return !reader.IsDBNull(ordinal) && reader.GetBoolean(ordinal);
        }

        private static DateTime GetDateTime(MySqlDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? DateTime.MinValue : reader.GetDateTime(ordinal);
        }

        private static DateTime? GetNullableDateTime(MySqlDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? null : reader.GetDateTime(ordinal);
        }
    }

    public sealed record HistoryLogEntry(
        string Id,
        DateTime Time,
        string Category,
        string Device,
        string Message,
        string Level,
        string Related,
        string Detail);

    public sealed record AlertHistoryEntry(
        long Id,
        string BedId,
        string DeviceId,
        string Level,
        string Type,
        string Message,
        int? Spo2,
        int? HeartRate,
        decimal? Temperature,
        int? DripRate,
        bool Acknowledged,
        DateTime CreatedAt,
        DateTime? AcknowledgedAt);
}
