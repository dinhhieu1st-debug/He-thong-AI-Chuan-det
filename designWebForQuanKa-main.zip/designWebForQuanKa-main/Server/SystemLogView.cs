using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Server
{
    public sealed class SystemLogView : UserControl
    {
        private const int PageSize = 80;

        private TextBox txtSearch = null!;
        private ComboBox cboDate = null!;
        private ComboBox cboLevel = null!;
        private ComboBox cboType = null!;
        private ComboBox cboBed = null!;
        private ComboBox cboRoom = null!;
        private DataGridView grid = null!;
        private Label lblTotal = null!;
        private Label lblWarnings = null!;
        private Label lblUserActions = null!;
        private Label lblErrors = null!;
        private Label lblLogId = null!;
        private Label lblTime = null!;
        private Label lblCategory = null!;
        private Label lblDevice = null!;
        private Label lblBed = null!;
        private Label lblLevel = null!;
        private Label lblDetail = null!;
        private Label lblPageInfo = null!;
        private Button btnPrev = null!;
        private Button btnNext = null!;
        private FlowLayoutPanel relatedFlow = null!;
        private readonly List<HistoryLogEntry> logs = new List<HistoryLogEntry>();
        private readonly MySqlHistoryRepository historyRepository = new MySqlHistoryRepository();
        private int currentPage;

        public SystemLogView()
        {
            Dock = DockStyle.Fill;
            BackColor = Color.FromArgb(244, 248, 253);

            TableLayoutPanel root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 4,
                Padding = new Padding(22, 16, 16, 16)
            };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 72));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 62));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 110));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            Controls.Add(root);

            root.Controls.Add(CreateHeader(), 0, 0);
            root.Controls.Add(CreateFilters(), 0, 1);
            root.Controls.Add(CreateStats(), 0, 2);
            root.Controls.Add(CreateContent(), 0, 3);

            HandleCreated += async (s, e) => await LoadLogsFromDatabaseAsync();
        }

        private Control CreateHeader()
        {
            TableLayoutPanel header = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 300));

            TableLayoutPanel titleBlock = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2, ColumnCount = 1 };
            titleBlock.RowStyles.Add(new RowStyle(SizeType.Percent, 58));
            titleBlock.RowStyles.Add(new RowStyle(SizeType.Percent, 42));
            Label title = MakeLabel("NHẬT KÝ HỆ THỐNG", 20, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            title.TextAlign = ContentAlignment.BottomLeft;
            Label subtitle = MakeLabel("Theo dõi lịch sử hoạt động, cảnh báo và kết nối thiết bị", 9, FontStyle.Regular, Color.FromArgb(95, 110, 130));
            subtitle.TextAlign = ContentAlignment.TopLeft;
            titleBlock.Controls.Add(title, 0, 0);
            titleBlock.Controls.Add(subtitle, 0, 1);
            header.Controls.Add(titleBlock, 0, 0);

            FlowLayoutPanel actions = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.RightToLeft,
                WrapContents = false,
                Padding = new Padding(0, 6, 0, 12)
            };
            Button refresh = MakeButton("⟳  Làm mới", Color.White, Color.FromArgb(18, 62, 112));
            refresh.Width = 122;
            refresh.Click += async (s, e) => await LoadLogsFromDatabaseAsync();
            Button export = MakeButton("↓  Xuất báo cáo", Color.FromArgb(0, 99, 255), Color.White);
            export.Width = 142;
            actions.Controls.Add(refresh);
            actions.Controls.Add(export);
            header.Controls.Add(actions, 1, 0);
            return header;
        }

        private Control CreateFilters()
        {
            FlowLayoutPanel filters = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                Padding = new Padding(0, 8, 0, 8)
            };

            txtSearch = new TextBox
            {
                Width = 360,
                Height = 32,
                Font = new Font("Segoe UI", 9),
                PlaceholderText = "Tìm theo thời gian, thiết bị, giường, phòng, nội dung..."
            };
            txtSearch.TextChanged += (s, e) =>
            {
                currentPage = 0;
                RenderLogs();
            };
            filters.Controls.Add(txtSearch);

            cboDate = AddCombo(filters, "Hôm nay", "Hôm nay", "7 ngày", "30 ngày");
            cboLevel = AddCombo(filters, "Mức độ", "Mức độ", "Nguy cấp", "Cảnh báo", "Thành công", "Thông tin");
            cboType = AddCombo(filters, "Loại nhật ký", "Loại nhật ký", "Cảnh báo", "Sinh tồn");
            cboBed = AddCombo(filters, "Giường", "Giường", "Giường 01", "Giường 02", "Giường 04");
            cboRoom = AddCombo(filters, "Phòng", "Phòng", "Phòng 01", "Phòng 02");
            return filters;
        }

        private Control CreateStats()
        {
            TableLayoutPanel stats = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 1 };
            for (int i = 0; i < 4; i++)
            {
                stats.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
            }

            lblTotal = AddStat(stats, 0, "▤", "TỔNG BẢN GHI", Color.FromArgb(0, 99, 255));
            lblWarnings = AddStat(stats, 1, "⚠", "CẢNH BÁO", Color.FromArgb(245, 132, 15));
            lblUserActions = AddStat(stats, 2, "○", "BẢN GHI SINH TỒN", Color.FromArgb(0, 150, 84));
            lblErrors = AddStat(stats, 3, "×", "LỖI HỆ THỐNG", Color.FromArgb(235, 54, 70));
            return stats;
        }

        private Control CreateContent()
        {
            TableLayoutPanel content = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 74));
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 26));

            Panel gridPanel = new Panel { Dock = DockStyle.Fill, BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle, Padding = new Padding(0), Margin = new Padding(0, 4, 8, 8) };
            Panel paging = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 48,
                BackColor = Color.White,
                Padding = new Padding(12, 7, 12, 7)
            };
            lblPageInfo = MakeLabel("0 bản ghi", 8, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            lblPageInfo.Dock = DockStyle.Left;
            lblPageInfo.Width = 260;
            lblPageInfo.TextAlign = ContentAlignment.MiddleLeft;
            paging.Controls.Add(lblPageInfo);

            FlowLayoutPanel pageButtons = new FlowLayoutPanel
            {
                Dock = DockStyle.Right,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                Width = 180
            };
            btnPrev = MakeButton("‹ Trước", Color.White, Color.FromArgb(0, 99, 255));
            btnPrev.Width = 78;
            btnPrev.Click += (s, e) =>
            {
                if (currentPage > 0)
                {
                    currentPage--;
                    RenderLogs();
                }
            };
            btnNext = MakeButton("Sau ›", Color.White, Color.FromArgb(0, 99, 255));
            btnNext.Width = 78;
            btnNext.Click += (s, e) =>
            {
                currentPage++;
                RenderLogs();
            };
            pageButtons.Controls.Add(btnPrev);
            pageButtons.Controls.Add(btnNext);
            paging.Controls.Add(pageButtons);
            grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                ReadOnly = true,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            grid.Columns.Add("time", "Thời gian ↓");
            grid.Columns.Add("type", "Loại");
            grid.Columns.Add("device", "Thiết bị/Giường");
            grid.Columns.Add("content", "Nội dung");
            grid.Columns.Add("level", "Mức độ");
            grid.CellClick += (s, e) =>
            {
                if (e.RowIndex >= 0 && grid.Rows[e.RowIndex].Tag is HistoryLogEntry log)
                {
                    ShowLogDetail(log);
                }
            };
            gridPanel.Controls.Add(grid);
            gridPanel.Controls.Add(paging);
            content.Controls.Add(gridPanel, 0, 0);
            content.Controls.Add(CreateDetailPanel(), 1, 0);
            return content;
        }

        private Control CreateDetailPanel()
        {
            Panel panel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Padding = new Padding(16),
                Margin = new Padding(8, 4, 0, 8)
            };

            TableLayoutPanel root = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 4, ColumnCount = 1 };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 210));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
            panel.Controls.Add(root);

            Label title = MakeLabel("CHI TIẾT NHẬT KÝ", 11, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            title.TextAlign = ContentAlignment.MiddleLeft;
            root.Controls.Add(title, 0, 0);

            TableLayoutPanel details = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 6 };
            details.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 43));
            details.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 57));
            for (int i = 0; i < 6; i++)
            {
                details.RowStyles.Add(new RowStyle(SizeType.Percent, 16.66f));
            }
            lblLogId = AddDetail(details, 0, "Mã log:");
            lblTime = AddDetail(details, 1, "Thời gian:");
            lblCategory = AddDetail(details, 2, "Loại:");
            lblDevice = AddDetail(details, 3, "Thiết bị:");
            lblBed = AddDetail(details, 4, "Giường:");
            lblLevel = AddDetail(details, 5, "Mức độ:");
            root.Controls.Add(details, 0, 1);

            TableLayoutPanel more = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 3, ColumnCount = 1 };
            more.RowStyles.Add(new RowStyle(SizeType.Absolute, 32));
            more.RowStyles.Add(new RowStyle(SizeType.Absolute, 92));
            more.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            Label detailTitle = MakeLabel("Nội dung chi tiết:", 8, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            detailTitle.TextAlign = ContentAlignment.MiddleLeft;
            lblDetail = MakeLabel("--", 8, FontStyle.Regular, Color.FromArgb(18, 43, 73));
            lblDetail.TextAlign = ContentAlignment.TopLeft;
            Label relatedTitle = MakeLabel("HOẠT ĐỘNG LIÊN QUAN", 8, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            relatedTitle.TextAlign = ContentAlignment.MiddleLeft;
            more.Controls.Add(detailTitle, 0, 0);
            more.Controls.Add(lblDetail, 0, 1);
            more.Controls.Add(relatedTitle, 0, 2);
            root.Controls.Add(more, 0, 2);

            relatedFlow = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true };
            more.Controls.Add(relatedFlow, 0, 2);

            FlowLayoutPanel actions = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft, WrapContents = false };
            actions.Controls.Add(MakeButton("✓  Đánh dấu đã xem", Color.FromArgb(0, 99, 255), Color.White));
            actions.Controls.Add(MakeButton("⌕  Xem liên quan", Color.White, Color.FromArgb(0, 99, 255)));
            root.Controls.Add(actions, 0, 3);
            return panel;
        }

        private async Task LoadLogsFromDatabaseAsync()
        {
            try
            {
                Cursor = Cursors.WaitCursor;
                logs.Clear();
                logs.AddRange(await historyRepository.LoadHistoryAsync());
                currentPage = 0;
                RenderLogs();
            }
            catch (Exception ex)
            {
                logs.Clear();
                grid.Rows.Clear();
                lblTotal.Text = "0";
                lblWarnings.Text = "0";
                lblUserActions.Text = "0";
                lblErrors.Text = "0";
                ShowEmptyDetail("Không đọc được dữ liệu MySQL", ex.Message);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        private void RenderLogs()
        {
            string keyword = txtSearch.Text.Trim();
            IEnumerable<HistoryLogEntry> visible = logs.Where(log =>
                (string.IsNullOrWhiteSpace(keyword)
                    || log.Device.Contains(keyword, StringComparison.OrdinalIgnoreCase)
                    || log.Message.Contains(keyword, StringComparison.OrdinalIgnoreCase)
                    || log.Related.Contains(keyword, StringComparison.OrdinalIgnoreCase)
                    || log.Category.Contains(keyword, StringComparison.OrdinalIgnoreCase))
                && (cboLevel.SelectedIndex <= 0 || log.Level == cboLevel.Text)
                && (cboType.SelectedIndex <= 0 || log.Category == cboType.Text));

            List<HistoryLogEntry> data = visible.ToList();
            int totalPages = Math.Max(1, (int)Math.Ceiling(data.Count / (double)PageSize));
            if (currentPage >= totalPages)
            {
                currentPage = totalPages - 1;
            }

            List<HistoryLogEntry> page = data
                .Skip(currentPage * PageSize)
                .Take(PageSize)
                .ToList();

            grid.Rows.Clear();
            foreach (HistoryLogEntry log in page)
            {
                int rowIndex = grid.Rows.Add(
                    log.Time.ToString("dd/MM/yyyy HH:mm:ss"),
                    GetTypeIcon(log.Category),
                    log.Device,
                    log.Message,
                    log.Level);
                DataGridViewRow row = grid.Rows[rowIndex];
                row.Tag = log;
                row.Height = 36;
                row.Cells[4].Style.ForeColor = GetLevelColor(log.Level);
                row.Cells[4].Style.Font = new Font("Segoe UI", 8, FontStyle.Bold);
            }

            lblTotal.Text = logs.Count.ToString();
            lblWarnings.Text = logs.Count(x => x.Level == "Cảnh báo" || x.Level == "Nguy cấp").ToString();
            lblUserActions.Text = logs.Count(x => x.Category == "Sinh tồn").ToString();
            lblErrors.Text = "0";
            lblPageInfo.Text = data.Count == 0
                ? "0 bản ghi"
                : $"Trang {currentPage + 1}/{totalPages} • {data.Count} bản ghi";
            btnPrev.Enabled = currentPage > 0;
            btnNext.Enabled = currentPage < totalPages - 1;

            if (page.Count > 0)
            {
                ShowLogDetail(page[0]);
            }
            else
            {
                ShowEmptyDetail("Chưa có dữ liệu", "Bảng alerts và vital_samples chưa có bản ghi phù hợp.");
            }
        }

        private void ShowLogDetail(HistoryLogEntry log)
        {
            lblLogId.Text = log.Id;
            lblTime.Text = log.Time.ToString("dd/MM/yyyy HH:mm:ss");
            lblCategory.Text = log.Category;
            lblDevice.Text = log.Device;
            lblBed.Text = log.Related;
            lblLevel.Text = log.Level;
            lblLevel.ForeColor = GetLevelColor(log.Level);
            lblDetail.Text = log.Detail;

            relatedFlow.Controls.Clear();
            foreach (HistoryLogEntry related in logs
                .Where(item => item.Id != log.Id && item.Related == log.Related)
                .OrderByDescending(item => item.Time)
                .Take(4))
            {
                relatedFlow.Controls.Add(MakeRelated(related.Time.ToString("HH:mm:ss"), related.Message));
            }
        }

        private void ShowEmptyDetail(string title, string detail)
        {
            lblLogId.Text = "--";
            lblTime.Text = "--";
            lblCategory.Text = title;
            lblDevice.Text = "--";
            lblBed.Text = "--";
            lblLevel.Text = "--";
            lblLevel.ForeColor = Color.FromArgb(18, 43, 73);
            lblDetail.Text = detail;
            relatedFlow.Controls.Clear();
        }

        private static ComboBox AddCombo(FlowLayoutPanel parent, string text, params string[] items)
        {
            ComboBox combo = new ComboBox
            {
                Width = 130,
                Height = 32,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 9),
                Margin = new Padding(6, 0, 6, 0)
            };
            combo.Items.AddRange(items.Cast<object>().ToArray());
            combo.SelectedIndex = 0;
            combo.SelectedIndexChanged += (s, e) =>
            {
                Control? parentControl = combo.Parent;
                while (parentControl != null && parentControl is not SystemLogView)
                {
                    parentControl = parentControl.Parent;
                }

                if (parentControl is SystemLogView view)
                {
                    view.currentPage = 0;
                    view.RenderLogs();
                }
            };
            parent.Controls.Add(combo);
            return combo;
        }

        private static Label AddStat(TableLayoutPanel parent, int column, string icon, string title, Color color)
        {
            Panel card = new Panel { Dock = DockStyle.Fill, Margin = new Padding(0, 8, 12, 10), BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle, Padding = new Padding(12) };
            TableLayoutPanel layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 58));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            Label iconLabel = MakeLabel(icon, 22, FontStyle.Bold, color);
            iconLabel.TextAlign = ContentAlignment.MiddleCenter;
            layout.Controls.Add(iconLabel, 0, 0);
            TableLayoutPanel text = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2, ColumnCount = 1 };
            text.RowStyles.Add(new RowStyle(SizeType.Percent, 58));
            text.RowStyles.Add(new RowStyle(SizeType.Percent, 42));
            Label number = MakeLabel("0", 16, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            Label caption = MakeLabel(title, 8, FontStyle.Bold, Color.FromArgb(95, 110, 130));
            number.TextAlign = ContentAlignment.BottomLeft;
            caption.TextAlign = ContentAlignment.TopLeft;
            text.Controls.Add(number, 0, 0);
            text.Controls.Add(caption, 0, 1);
            layout.Controls.Add(text, 1, 0);
            card.Controls.Add(layout);
            parent.Controls.Add(card, column, 0);
            return number;
        }

        private static Label AddDetail(TableLayoutPanel parent, int row, string title)
        {
            Label left = MakeLabel(title, 8, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            Label right = MakeLabel("--", 8, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            left.TextAlign = ContentAlignment.MiddleLeft;
            right.TextAlign = ContentAlignment.MiddleRight;
            parent.Controls.Add(left, 0, row);
            parent.Controls.Add(right, 1, row);
            return right;
        }

        private static Control MakeRelated(string time, string text)
        {
            Label row = MakeLabel(time + "  •  " + text, 8, FontStyle.Bold, Color.FromArgb(18, 43, 73));
            row.Height = 30;
            row.Width = 260;
            row.TextAlign = ContentAlignment.MiddleLeft;
            return row;
        }

        private static Button MakeButton(string text, Color backColor, Color foreColor)
        {
            Button button = new Button
            {
                Text = text,
                Width = 132,
                Height = 34,
                Margin = new Padding(6, 4, 6, 4),
                FlatStyle = FlatStyle.Flat,
                BackColor = backColor,
                ForeColor = foreColor,
                Font = new Font("Segoe UI", 8, FontStyle.Bold)
            };
            button.FlatAppearance.BorderColor = Color.FromArgb(205, 220, 242);
            return button;
        }

        private static string GetTypeIcon(string category)
        {
            if (category == "Cảnh báo")
            {
                return "⚠";
            }

            if (category == "Sinh tồn")
            {
                return "✓";
            }

            return "ⓘ";
        }

        private static Color GetLevelColor(string level)
        {
            if (level == "Nguy cấp")
            {
                return Color.FromArgb(235, 54, 70);
            }

            if (level == "Cảnh báo")
            {
                return Color.FromArgb(245, 132, 15);
            }

            if (level == "Thành công")
            {
                return Color.FromArgb(0, 150, 84);
            }

            return Color.FromArgb(0, 99, 255);
        }

        private static Label MakeLabel(string text, int size, FontStyle style, Color color)
        {
            return new Label
            {
                Text = text,
                Dock = DockStyle.Fill,
                AutoSize = false,
                Font = new Font("Segoe UI", size, style),
                ForeColor = color
            };
        }

    }
}
