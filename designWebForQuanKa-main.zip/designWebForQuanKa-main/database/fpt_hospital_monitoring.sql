-- Minimal MySQL schema for HIS Server history storage.
-- This script creates only the tables currently needed by the server:
--   1. vital_samples: raw vital-sign history
--   2. alerts: alert history
--
-- It does not insert demo/fake data.

CREATE DATABASE IF NOT EXISTS fpt_hospital_monitoring
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE fpt_hospital_monitoring;

CREATE TABLE IF NOT EXISTS vital_samples (
  sample_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  bed_id VARCHAR(50) NOT NULL,
  device_id VARCHAR(80),
  spo2 INT,
  heart_rate INT,
  temperature DECIMAL(4,1),
  drip_rate INT,
  sample_status ENUM('ON_DINH', 'CANH_BAO', 'NGUY_CAP') NOT NULL DEFAULT 'ON_DINH',
  recorded_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  KEY idx_vital_samples_bed_time (bed_id, recorded_at),
  KEY idx_vital_samples_device_time (device_id, recorded_at),
  KEY idx_vital_samples_time (recorded_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS alerts (
  alert_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  bed_id VARCHAR(50) NOT NULL,
  device_id VARCHAR(80),
  alert_level ENUM('CANH_BAO', 'NGUY_CAP') NOT NULL,
  alert_type VARCHAR(100) NOT NULL,
  message VARCHAR(255) NOT NULL,
  spo2 INT,
  heart_rate INT,
  temperature DECIMAL(4,1),
  drip_rate INT,
  acknowledged BOOLEAN NOT NULL DEFAULT FALSE,
  acknowledged_at DATETIME,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_alerts_bed_time (bed_id, created_at),
  KEY idx_alerts_ack_time (acknowledged, created_at),
  KEY idx_alerts_level_time (alert_level, created_at),
  KEY idx_alerts_time (created_at)
) ENGINE=InnoDB;

SELECT 'fpt_hospital_monitoring history schema ready' AS status;
